import React, { useState } from 'react';
import { useApp } from '@/lib/AppContext';
import { useI18n } from '@/lib/i18n';
import FadeInSection from '@/components/FadeInSection';
import MonoLabel from '@/components/MonoLabel';
import HorizonLine from '@/components/HorizonLine';
import TableOfContents from '@/components/TableOfContents';
import { FileText, Award, Database, Trophy, ExternalLink, Code } from 'lucide-react';

const tocSections = [
  { id: 'inno-overview',    label_en: 'Overview',    label_zh: '概览' },
  { id: 'inno-papers',      label_en: 'Publications', label_zh: '学术论文' },
  { id: 'inno-patents',     label_en: 'Patents',      label_zh: '专利' },
  { id: 'inno-datasets',    label_en: 'Datasets',     label_zh: '数据集' },
  { id: 'inno-awards',      label_en: 'Awards',       label_zh: '奖项' },
];

const papers = [
  { title: 'AetherEarth: Unified Foundation Model for Earth System Modeling', authors: 'Zhang, L. · Chen, M. · Park, J. · Liu, R.', venue: 'NeurIPS 2026', year: '2026', area: 'Planet AI', abstract: 'We present AetherEarth, a 100B-parameter foundation model for multi-scale Earth system simulation, trained on 50 years of global atmospheric, oceanic, and terrestrial data.' },
  { title: 'Scaling Scientific Foundation Models Beyond 100B Parameters', authors: 'Wang, H. · Garcia, E. · Kim, Y. · Aoki, S.', venue: 'NeurIPS 2026', year: '2026', area: 'General AI', abstract: 'We investigate emergent scientific reasoning capabilities in foundation models at unprecedented scale, demonstrating step-change improvements in hypothesis generation.' },
  { title: 'Learning Robust Drone Policies from Imperfect Simulations', authors: 'Liu, R. · Nguyen, T. · Chen, M.', venue: 'CVPR 2026', year: '2026', area: 'Embodied AI', abstract: 'We propose a novel domain randomization and adaptation strategy enabling robust sim-to-real transfer for autonomous drone navigation in unstructured environments.' },
  { title: 'Neural Climate Simulators with Uncertainty Quantification', authors: 'Park, J. · Zhang, L. · Kim, Y.', venue: 'Nature Machine Intelligence', year: '2026', area: 'Planet AI', abstract: 'A probabilistic neural architecture that provides calibrated uncertainty estimates for long-range climate projections, outperforming ensemble physical models.' },
  { title: 'Embodied Reasoning in Unstructured Physical Environments', authors: 'Garcia, E. · Wang, H. · Aoki, S.', venue: 'ICML 2026', year: '2026', area: 'Embodied AI', abstract: 'We introduce an embodied reasoning benchmark and propose a multi-modal agent architecture achieving human-level performance on physical manipulation tasks.' },
  { title: 'Crystal Structure Prediction via Graph Neural Networks', authors: 'Nguyen, T. · Liu, R. · Chen, M.', venue: 'Nature Computational Science', year: '2026', area: 'Embodied AI', abstract: 'A graph-based generative model for predicting stable crystal structures with target properties, accelerating material discovery by orders of magnitude.' },
];

const patents = [
  { title: 'Autonomous Multi-Agent Drone Swarm Coordination System', inventors: 'Zhang, L. · Chen, M.', year: '2026', area: 'Embodied AI', id: 'PCT/CN2026/001234' },
  { title: 'AI-Based Real-Time Ocean Current Prediction Method', inventors: 'Park, J. · Liu, R.', year: '2025', area: 'Planet AI', id: 'PCT/CN2025/005678' },
  { title: 'Neural Material Property Prediction Architecture', inventors: 'Nguyen, T. · Wang, H.', year: '2025', area: 'Embodied AI', id: 'PCT/CN2025/009012' },
  { title: 'Foundation Model Pre-training on Scientific Corpora', inventors: 'Kim, Y. · Garcia, E.', year: '2026', area: 'General AI', id: 'PCT/CN2026/003456' },
];

const datasets = [
  { name: 'AetherClimate-50', desc: '50 years of global climate reanalysis data at 0.1° spatial resolution.', size: '2.4 TB', access: 'Open', area: 'Planet AI' },
  { name: 'OceanDepth-HD', desc: 'High-resolution deep ocean observation dataset from 1000+ sensor buoys.', size: '890 GB', access: 'Open', area: 'Planet AI' },
  { name: 'DroneNav-1M', desc: '1 million drone flight trajectories across diverse physical environments.', size: '4.2 TB', access: 'Open', area: 'Embodied AI' },
  { name: 'CrystalGen-500K', desc: '500K crystal structures with computed material properties for ML training.', size: '120 GB', access: 'Open', area: 'Embodied AI' },
  { name: 'SciPaper-10M', desc: '10 million scientific papers with structured knowledge graph annotations.', size: '1.8 TB', access: 'Restricted', area: 'General AI' },
  { name: 'BenchSci-Core', desc: 'Comprehensive scientific reasoning benchmark across 12 disciplines.', size: '8 GB', access: 'Open', area: 'General AI' },
];

const awards = [
  { title: 'Best Paper Award', venue: 'ICLR 2026', desc: 'Embodied Intelligence Track — "Embodied Reasoning in Unstructured Physical Environments"', year: '2026' },
  { title: 'Outstanding Research Award', venue: 'AAAI 2026', desc: 'General AI Track — "Scaling Scientific Foundation Models"', year: '2026' },
  { title: 'Best Demo Award', venue: 'CVPR 2026', desc: 'Autonomous Systems Demo — AetherDrone live demonstration', year: '2026' },
  { title: 'Nature Research Excellence Award', venue: 'Nature Portfolio', desc: 'For contributions to AI-driven climate science', year: '2025' },
];

const TABS = [
  { key: 'papers', icon: FileText },
  { key: 'patents', icon: Code },
  { key: 'datasets', icon: Database },
  { key: 'awards', icon: Trophy },
];

export default function Innovations() {
  const { lang } = useApp();
  const t = useI18n(lang);
  const [activeTab, setActiveTab] = useState('papers');
  const [filter, setFilter] = useState('All');

  const labels = {
    en: { papers: 'Publications', patents: 'Patents & IP', datasets: 'Datasets & Benchmarks', awards: 'Awards' },
    zh: { papers: '学术论文', patents: '专利与IP', datasets: '数据集与基准', awards: '奖项' },
  };

  const areaFilters = ['All', 'Planet AI', 'Embodied AI', 'General AI'];
  const areaFiltersZh = ['全部', '环境AI', '物理AI', '通用AI'];
  const filters = lang === 'en' ? areaFilters : areaFiltersZh;

  const areaMap = { 'Planet AI': 0, 'Embodied AI': 1, 'General AI': 2 };
  const filterKey = lang === 'zh'
    ? { '全部': 'All', '环境AI': 'Planet AI', '物理AI': 'Embodied AI', '通用AI': 'General AI' }[filter]
    : filter;

  const filteredPapers = filterKey === 'All' ? papers : papers.filter(p => p.area === filterKey);
  const filteredDatasets = filterKey === 'All' ? datasets : datasets.filter(d => d.area === filterKey);
  const filteredPatents = filterKey === 'All' ? patents : patents.filter(p => p.area === filterKey);

  return (
    <div className="pt-24">
      <TableOfContents sections={tocSections} />

      <section id="inno-overview" className="px-6 lg:px-10 py-20 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-4 block">{lang === 'en' ? 'Research Output' : '研究成果'}</MonoLabel>
          <h1 className="text-[clamp(2.5rem,6vw,6rem)] font-bold tracking-tight mb-4">{t.innovationsPage.title}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">{t.innovationsPage.subtitle}</p>
        </FadeInSection>
      </section>

      <HorizonLine />

      <section className="px-6 lg:px-10 pb-20 max-w-[1400px] mx-auto">
        {/* Tab Bar */}
        <div className="flex flex-wrap gap-2 mb-10">
          {TABS.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium transition-all duration-200 min-h-[44px] ${
                  activeTab === tab.key
                    ? 'bg-primary text-primary-foreground border-primary shadow-md shadow-primary/20'
                    : 'border-border/50 text-muted-foreground hover:text-foreground hover:border-primary/40'
                }`}
              >
                <Icon size={15} />
                {labels[lang][tab.key]}
              </button>
            );
          })}
        </div>

        {/* Area Filter */}
        {activeTab !== 'awards' && (
          <div className="flex flex-wrap gap-2 mb-8">
            {filters.map(f => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`mono-label text-[11px] px-3 py-1.5 rounded-full border transition-all min-h-[36px] ${
                  filter === f ? 'border-primary text-primary bg-primary/10' : 'border-border/50 text-muted-foreground hover:border-primary/40'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        )}

        {/* Papers */}
        <div id="inno-papers" />
        {activeTab === 'papers' && (
          <div className="grid grid-cols-1 gap-4">
            {filteredPapers.map((paper, i) => (
              <FadeInSection key={i} delay={i * 60}>
                <div className="group rounded-2xl border border-border/50 dark:bg-card/40 bg-card p-6 hover:border-primary/40 hover:shadow-lg transition-all duration-300">
                  <div className="flex flex-col lg:flex-row lg:items-start gap-4">
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center gap-2 mb-3">
                        <span className="mono-label text-[10px] px-2 py-1 rounded border border-primary/30 text-primary">{paper.venue}</span>
                        <span className="mono-label text-[10px] text-muted-foreground/50">{paper.year}</span>
                        <span className="mono-label text-[10px] px-2 py-1 rounded-full bg-muted text-muted-foreground">{paper.area}</span>
                      </div>
                      <h3 className="text-base font-semibold mb-2 group-hover:text-primary transition-colors">{paper.title}</h3>
                      <p className="text-xs text-muted-foreground mb-3">{paper.authors}</p>
                      <p className="text-sm text-muted-foreground/80 leading-relaxed">{paper.abstract}</p>
                    </div>
                    <div className="flex lg:flex-col gap-2 shrink-0">
                      <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-primary/30 text-primary text-xs hover:bg-primary/10 transition-colors min-h-[44px]">
                        <FileText size={13} /> PDF
                      </button>
                      <button className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border text-muted-foreground text-xs hover:text-foreground hover:border-primary/30 transition-colors min-h-[44px]">
                        <Code size={13} /> Code
                      </button>
                    </div>
                  </div>
                </div>
              </FadeInSection>
            ))}
          </div>
        )}

        {/* Patents */}
        <div id="inno-patents" />
        {activeTab === 'patents' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPatents.map((patent, i) => (
              <FadeInSection key={i} delay={i * 80}>
                <div className="group rounded-2xl border border-border/50 dark:bg-card/40 bg-card p-6 hover:border-primary/40 transition-all duration-300 h-full">
                  <MonoLabel className="text-[10px] text-muted-foreground/50 mb-3 block">{patent.id}</MonoLabel>
                  <h3 className="text-base font-semibold mb-2 group-hover:text-primary transition-colors">{patent.title}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{patent.inventors}</p>
                  <div className="flex items-center gap-3 mt-auto">
                    <span className="mono-label text-[10px] px-2 py-1 rounded-full bg-muted text-muted-foreground">{patent.area}</span>
                    <span className="mono-label text-[10px] text-muted-foreground/50">{patent.year}</span>
                  </div>
                </div>
              </FadeInSection>
            ))}
          </div>
        )}

        {/* Datasets */}
        <div id="inno-datasets" />
        {activeTab === 'datasets' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDatasets.map((ds, i) => (
              <FadeInSection key={i} delay={i * 60}>
                <div className="group rounded-2xl border border-border/50 dark:bg-card/40 bg-card p-6 hover:border-primary/40 hover:shadow-md transition-all duration-300 h-full flex flex-col">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-base font-semibold group-hover:text-primary transition-colors">{ds.name}</h3>
                    <span className={`mono-label text-[10px] px-2 py-1 rounded-full border shrink-0 ml-2 ${
                      ds.access === 'Open' ? 'bg-green-500/10 text-green-500 border-green-500/20' : 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                    }`}>
                      {ds.access}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground flex-1 mb-4">{ds.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="mono-label text-[10px] text-muted-foreground/50">{ds.size}</span>
                    <button className="flex items-center gap-1 text-xs text-primary hover:underline min-h-[44px] px-2">
                      <ExternalLink size={12} /> {lang === 'en' ? 'Download' : '下载'}
                    </button>
                  </div>
                </div>
              </FadeInSection>
            ))}
          </div>
        )}

        {/* Awards */}
        <div id="inno-awards" />
        {activeTab === 'awards' && (
          <div className="flex flex-col gap-4">
            {awards.map((award, i) => (
              <FadeInSection key={i} delay={i * 80}>
                <div className="group flex items-start gap-6 rounded-2xl border border-border/50 dark:bg-card/40 bg-card p-6 hover:border-primary/40 transition-all duration-300">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                    <Trophy size={20} className="text-amber-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <h3 className="text-base font-semibold group-hover:text-primary transition-colors">{award.title}</h3>
                      <span className="mono-label text-[10px] px-2 py-1 rounded border border-amber-500/30 text-amber-500">{award.year}</span>
                    </div>
                    <p className="mono-label text-[11px] text-primary/70 mb-1">{award.venue}</p>
                    <p className="text-sm text-muted-foreground">{award.desc}</p>
                  </div>
                </div>
              </FadeInSection>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}