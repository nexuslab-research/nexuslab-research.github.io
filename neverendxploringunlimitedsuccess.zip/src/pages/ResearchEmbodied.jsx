import React from 'react';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';
import MonoLabel from '@/components/MonoLabel';
import HorizonLine from '@/components/HorizonLine';
import TableOfContents from '@/components/TableOfContents';
import { Zap, ChevronRight, Play, ExternalLink } from 'lucide-react';

const tocSections = [
  { id: 'ei-overview',      label_en: 'Overview',             label_zh: '概览' },
  { id: 'ei-drone',         label_en: 'Drone Brain',          label_zh: '无人机大脑' },
  { id: 'ei-manufacturing', label_en: 'Manufacturing',        label_zh: '智能制造' },
  { id: 'ei-materials',     label_en: 'Material Discovery',   label_zh: '材料发现' },
  { id: 'ei-projects',      label_en: 'Projects',             label_zh: '研究项目' },
  { id: 'ei-patents',       label_en: 'Patents',              label_zh: '专利' },
  { id: 'ei-products',      label_en: 'Products',             label_zh: '产品' },
  { id: 'ei-demos',         label_en: 'Demo Videos',          label_zh: '演示视频' },
];

const droneFeatures = [
  { en: 'End-to-end neural architecture for real-time obstacle avoidance', zh: '端到端神经架构实现实时障碍物规避' },
  { en: 'Multi-drone swarm coordination with decentralized control', zh: '去中心化控制的多无人机集群协调' },
  { en: 'On-edge AI inference at <20ms latency', zh: '边缘端AI推理延迟低于20毫秒' },
  { en: 'Robust sim-to-real transfer across diverse environments', zh: '跨多样化环境的鲁棒仿真-现实迁移' },
];

const manufacturingFeatures = [
  { en: 'Vision-based quality inspection achieving 99.2% defect detection', zh: '基于视觉的质量检验，缺陷检出率达99.2%' },
  { en: 'Real-time process optimization reducing energy consumption by 28%', zh: '实时工艺优化，降低能耗28%' },
  { en: 'Predictive maintenance reducing unplanned downtime by 35%', zh: '预测性维护，减少非计划停机35%' },
  { en: 'Digital twin integration for live process simulation', zh: '数字孪生集成实现实时工艺仿真' },
];

const materialFeatures = [
  { en: 'Graph neural networks predicting crystal structures from composition', zh: '图神经网络从成分预测晶体结构' },
  { en: 'Generative models for inverse material design', zh: '面向逆向材料设计的生成模型' },
  { en: '500K crystal structure dataset with computed properties', zh: '含计算属性的50万晶体结构数据集' },
  { en: 'Active learning loops accelerating experimental validation', zh: '主动学习循环加速实验验证' },
];

const projects = [
  { name: 'DroneForge', status: 'Active', en: 'End-to-end neural architecture for autonomous drone navigation in complex unstructured environments, powered by multi-modal sensor fusion.', zh: '端到端神经架构驱动的复杂非结构化环境自主无人机导航，基于多模态传感器融合。' },
  { name: 'MaterialMind', status: 'Active', en: 'AI-driven discovery of novel materials with targeted physical properties using graph-based generative models and active learning.', zh: '利用图生成模型和主动学习进行具有目标物理属性的新型材料AI驱动发现。' },
  { name: 'RoboSynth', status: 'Active', en: 'Sim-to-real transfer learning framework for intelligent manufacturing robotics, combining domain randomization and adaptation networks.', zh: '智能制造机器人仿真-现实迁移学习框架，结合域随机化和自适应网络。' },
];

const patents = [
  { id: 'PCT/CN2026/001234', title: 'Autonomous Multi-Agent Drone Swarm Coordination System', year: '2026', inventors: 'Zhang, L. · Chen, M.' },
  { id: 'PCT/CN2025/009012', title: 'Neural Material Property Prediction Architecture', year: '2025', inventors: 'Nguyen, T. · Wang, H.' },
  { id: 'PCT/CN2026/007890', title: 'Real-Time Vision-Based Quality Inspection for Manufacturing', year: '2026', inventors: 'Garcia, E. · Kim, Y.' },
];

const products = [
  { name: 'Aether Drone Intelligence', en: 'Commercial AI drone system for environmental monitoring and infrastructure inspection.', zh: '用于环境监测和基础设施检测的商业AI无人机系统。', link: '/products' },
  { name: 'Manufacturing AI Suite', en: 'End-to-end AI for intelligent manufacturing — process optimization, quality, and maintenance.', zh: '端到端智能制造AI——工艺优化、质量控制与预测维护。', link: '/products' },
];

const demos = [
  { title: 'AetherDrone: Autonomous Navigation in Forest', titleZh: 'AetherDrone：森林自主导航', venue: 'CVPR 2026 Demo' },
  { title: 'MaterialMind: Discovering Superconductors with AI', titleZh: 'MaterialMind：AI发现超导体', venue: 'NeurIPS 2026' },
  { title: 'Swarm Coordination: 12-Drone Indoor Formation', titleZh: '集群协调：12架无人机室内编队', venue: 'Internal Demo' },
];

export default function ResearchEmbodied() {
  const { lang } = useApp();

  return (
    <div className="pt-24">
      <TableOfContents sections={tocSections} />

      {/* Header */}
      <section id="ei-overview" className="px-6 lg:px-10 py-20 max-w-[1400px] mx-auto">
        <FadeInSection>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 border border-violet-500/25 bg-violet-500/10 mb-8">
            <Zap size={13} className="text-violet-400" />
            <MonoLabel className="text-[10px] text-violet-400">
              {lang === 'en' ? 'Embodied Intelligence' : '物理智能'}
            </MonoLabel>
          </div>
          <h1 className="text-[clamp(2.5rem,6vw,6rem)] font-bold tracking-tight mb-4">
            {lang === 'en' ? 'Embodied Intelligence' : '物理智能'}
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            {lang === 'en'
              ? 'Physical AI that reasons about space, force, and material — enabling autonomous drones, intelligent manufacturing, and accelerated materials discovery.'
              : '能够推理空间、力和物质的物理AI——驱动自主无人机、智能制造与加速材料发现。'}
          </p>
        </FadeInSection>
      </section>

      <HorizonLine />

      {/* Drone Brain */}
      <section id="ei-drone" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Drone Brain' : '无人机大脑'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-4">
            {lang === 'en' ? 'Autonomous Aerial Intelligence' : '自主飞行智能'}
          </h2>
          <p className="text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            {lang === 'en'
              ? 'DroneForge is our flagship neural architecture enabling robust autonomous navigation in complex, unstructured environments — from forests to industrial facilities.'
              : 'DroneForge是我们的旗舰神经架构，能够在从森林到工业设施等复杂非结构化环境中实现鲁棒自主导航。'}
          </p>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border/20">
          {droneFeatures.map((f, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="bg-background p-7 hover:bg-foreground/[0.02] transition-colors">
                <div className="flex items-start gap-4">
                  <MonoLabel className="text-[9px] text-violet-400/60 shrink-0 mt-0.5">{String(i + 1).padStart(2, '0')}</MonoLabel>
                  <p className="text-[14px] text-foreground/70 leading-relaxed">{lang === 'en' ? f.en : f.zh}</p>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Manufacturing */}
      <section id="ei-manufacturing" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Intelligent Manufacturing' : '智能制造'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-4">
            {lang === 'en' ? 'AI for Industry' : '工业AI'}
          </h2>
          <p className="text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            {lang === 'en'
              ? 'RoboSynth bridges simulation and reality, enabling AI systems trained in virtual environments to operate robustly on real production lines.'
              : 'RoboSynth连接仿真与现实，使在虚拟环境中训练的AI系统能够在真实生产线上稳健运行。'}
          </p>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border/20">
          {manufacturingFeatures.map((f, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="bg-background p-7 hover:bg-foreground/[0.02] transition-colors">
                <div className="flex items-start gap-4">
                  <MonoLabel className="text-[9px] text-violet-400/60 shrink-0 mt-0.5">{String(i + 1).padStart(2, '0')}</MonoLabel>
                  <p className="text-[14px] text-foreground/70 leading-relaxed">{lang === 'en' ? f.en : f.zh}</p>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Material Discovery */}
      <section id="ei-materials" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Material Discovery' : '材料发现'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-4">
            {lang === 'en' ? 'AI-Driven Materials Science' : 'AI驱动的材料科学'}
          </h2>
          <p className="text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            {lang === 'en'
              ? 'MaterialMind uses graph neural networks and generative models to predict, design, and discover novel materials orders of magnitude faster than conventional methods.'
              : 'MaterialMind使用图神经网络和生成模型，以比传统方法快数个数量级的速度预测、设计和发现新型材料。'}
          </p>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border/20">
          {materialFeatures.map((f, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="bg-background p-7 hover:bg-foreground/[0.02] transition-colors">
                <div className="flex items-start gap-4">
                  <MonoLabel className="text-[9px] text-violet-400/60 shrink-0 mt-0.5">{String(i + 1).padStart(2, '0')}</MonoLabel>
                  <p className="text-[14px] text-foreground/70 leading-relaxed">{lang === 'en' ? f.en : f.zh}</p>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Projects */}
      <section id="ei-projects" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Research Projects' : '研究项目'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Active Projects' : '活跃项目'}
          </h2>
        </FadeInSection>
        <div className="space-y-4">
          {projects.map((proj, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-violet-500/15 hover:border-violet-500/35 transition-all p-8 cursor-pointer">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-lg font-semibold group-hover:text-violet-400 transition-colors">{proj.name}</h3>
                      <span className="mono-label text-[9px] px-2 py-0.5 border border-green-500/25 bg-green-500/10 text-green-400">{proj.status}</span>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{lang === 'en' ? proj.en : proj.zh}</p>
                  </div>
                  <ChevronRight size={16} className="text-foreground/20 group-hover:text-violet-400 transition-colors ml-6 mt-1 shrink-0" />
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Patents */}
      <section id="ei-patents" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Patents & IP' : '专利与知识产权'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Intellectual Property' : '知识产权'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {patents.map((p, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-violet-500/30 transition-all p-6">
                <MonoLabel className="text-[9px] text-foreground/25 mb-3 block">{p.id}</MonoLabel>
                <h3 className="font-medium mb-2 group-hover:text-violet-400 transition-colors text-[14px]">{p.title}</h3>
                <p className="text-xs text-muted-foreground mb-3">{p.inventors}</p>
                <MonoLabel className="text-[9px] text-foreground/30">{p.year}</MonoLabel>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Products */}
      <section id="ei-products" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Products' : '商业产品'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Commercial Applications' : '商业化应用'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {products.map((prod, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-violet-500/30 transition-all p-8">
                <h3 className="font-semibold text-lg mb-3 group-hover:text-violet-400 transition-colors">{prod.name}</h3>
                <p className="text-muted-foreground mb-6 leading-relaxed">{lang === 'en' ? prod.en : prod.zh}</p>
                <a href={prod.link} className="inline-flex items-center gap-2 mono-label text-[10px] text-foreground/40 hover:text-foreground transition-colors">
                  {lang === 'en' ? 'View Product' : '查看产品'} <ExternalLink size={10} />
                </a>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Demo Videos */}
      <section id="ei-demos" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Demo Videos' : '演示视频'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'System Demonstrations' : '系统演示'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {demos.map((demo, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-violet-500/30 transition-all cursor-pointer">
                <div className="aspect-video bg-foreground/[0.03] flex items-center justify-center relative">
                  <div className="w-14 h-14 border border-foreground/15 flex items-center justify-center group-hover:border-violet-500/40 transition-colors">
                    <Play size={20} className="text-foreground/25 group-hover:text-violet-400 transition-colors ml-1" />
                  </div>
                  <MonoLabel className="absolute bottom-3 right-3 text-[8px] text-foreground/25">{demo.venue}</MonoLabel>
                </div>
                <div className="p-5">
                  <p className="text-[13px] font-medium text-foreground/75 group-hover:text-foreground transition-colors leading-snug">
                    {lang === 'en' ? demo.title : demo.titleZh}
                  </p>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>
    </div>
  );
}