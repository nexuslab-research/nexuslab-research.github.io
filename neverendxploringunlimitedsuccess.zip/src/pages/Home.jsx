import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useApp } from '@/lib/AppContext';
import AetherField from '@/components/AetherField';
import FadeInSection from '@/components/FadeInSection';
import HeroTitle from '@/components/HeroTitle';

const outputCategories = [
  { en: 'Publications', zh: '论文', desc_en: 'Peer-reviewed papers', desc_zh: '期刊与会议', href: '/research/publications' },
  { en: 'Patents', zh: '专利', desc_en: 'Patents & Software Copyrights', desc_zh: '专利与软著', href: '/research/patents' },
  { en: 'Other Projects', zh: '评测与产品', desc_en: 'Datasets, benchmarks & products', desc_zh: '数据集、评测与产品', href: '/research/other-projects' },
];

export default function Home() {
  const { lang } = useApp();
  const [latestOutputs, setLatestOutputs] = useState([]);

  useEffect(() => {
    base44.entities.Publication.list('-created_date', 500)
      .then(data => {
        const pubs = (data || []).slice().sort((a, b) => {
          const ay = String(a.year || '');
          const by = String(b.year || '');
          return by.localeCompare(ay);
        }).slice(0, 4);
        setLatestOutputs(pubs.map(p => ({
          date: p.year || '',
          type: lang === 'en' ? 'Paper' : '论文',
          title: p.title || '',
          venue: p.venue || '',
          href: `/research/publications/${p.id}`,
        })));
      })
      .catch(() => setLatestOutputs([]));
  }, [lang]);

  return (
    <div className="overflow-x-hidden">
      {/* HERO — 保留地球/银河系可视化 */}
      <section className="relative min-h-[85vh] flex flex-col items-center justify-center overflow-hidden bg-background">
        <AetherField />

        <div className="absolute inset-0 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse 80% 70% at 50% 50%, transparent 30%, var(--vignette-color, rgba(0,0,0,0.5)) 100%)' }}
        />

        <div className="relative z-10 w-full max-w-6xl mx-auto px-6 flex flex-col items-center justify-center gap-6 pt-10 lg:pt-14">
          <FadeInSection delay={200}>
            <HeroTitle />
          </FadeInSection>

          <FadeInSection delay={350}>
            <div className="flex items-center gap-4">
              <Link to="/research/publications"
                className="group flex items-center gap-2 px-7 py-3 border border-border hover:border-foreground/40 transition-all duration-300">
                <span className="text-[14px] text-foreground/70 group-hover:text-foreground transition-colors">
                  {lang === 'en' ? 'Enter Research' : '进入研究'}
                </span>
                <ArrowUpRight size={13} className="text-foreground/40 group-hover:text-foreground/70 transition-colors" />
              </Link>
              <Link to="/about"
                className="group flex items-center gap-2 px-7 py-3 border border-border hover:border-foreground/40 transition-all duration-300">
                <span className="text-[14px] text-foreground/60 group-hover:text-foreground transition-colors">
                  {lang === 'en' ? 'Contact' : '联系我们'}
                </span>
              </Link>
            </div>
          </FadeInSection>
        </div>
      </section>

      {/* 最新动态 */}
      <section className="py-12 px-6 lg:px-10 max-w-[1100px] mx-auto">
        <FadeInSection>
          <div className="flex items-end justify-between mb-6">
            <h2 className="text-[clamp(1.6rem,3.5vw,2.5rem)] font-bold tracking-tight text-foreground">
              {lang === 'en' ? 'News' : '最新动态'}
            </h2>
          </div>
        </FadeInSection>

        <div className="divide-y divide-border">
          {latestOutputs.map((item, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <Link to={item.href} className="group block py-5 flex items-center gap-6 hover:bg-foreground/[0.02] -mx-4 px-4 transition-colors">
                <div className="w-20 shrink-0 hidden sm:block">
                  <span className="text-[12px] text-muted-foreground tabular-nums">{item.date}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[15px] font-medium text-foreground/85 group-hover:text-foreground transition-colors leading-snug">{item.title}</p>
                  <span className="text-[12px] text-muted-foreground mt-1 block">{item.venue}</span>
                </div>
                <span className="text-[11px] text-muted-foreground border border-border px-2 py-1 shrink-0 hidden sm:inline-block">
                  {item.type}
                </span>
                <ArrowUpRight size={13} className="text-foreground/30 group-hover:text-foreground/60 transition-colors shrink-0" />
              </Link>
            </FadeInSection>
          ))}
        </div>
      </section>

      {/* 研究成果 */}
      <section className="py-12 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <div className="flex items-end justify-between mb-6">
            <h2 className="text-[clamp(1.6rem,3.5vw,2.5rem)] font-bold tracking-tight text-foreground">
              {lang === 'en' ? 'Research Outputs' : '研究成果'}
            </h2>

          </div>
        </FadeInSection>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {outputCategories.map((o, i) => (
            <FadeInSection key={o.href} delay={i * 70}>
              <Link to={o.href}>
                <div className="group border border-border hover:border-foreground/30 p-8 transition-colors h-full flex flex-col gap-4 min-h-[180px]">
                  <h3 className="text-[18px] font-bold text-foreground/80 group-hover:text-foreground transition-colors">{lang === 'en' ? o.en : o.zh}</h3>
                  <p className="text-[13px] text-muted-foreground leading-relaxed flex-1">{lang === 'en' ? o.desc_en : o.desc_zh}</p>
                  <ArrowUpRight size={14} className="text-foreground/30 group-hover:text-foreground/60 transition-colors" />
                </div>
              </Link>
            </FadeInSection>
          ))}
        </div>
      </section>

      {/* 使命 */}
      <section className="py-16 px-6 lg:px-10 max-w-3xl mx-auto border-t border-border">
        <FadeInSection>
          <div className="text-center">
            <h2 className="text-[clamp(1.32rem,3.6vw,2.7rem)] font-bold tracking-tight text-foreground mb-5 leading-[1.05]">
              {lang === 'en'
                ? 'One Mind, Many Embodiments.'
                : '一脑多形，智能无界'}
            </h2>
            <p className="text-[14px] text-muted-foreground leading-relaxed mb-12 max-w-xl mx-auto font-light">
              {lang === 'en'
                ? 'Embodied intelligence evaluation, cross-embodiment adaptation, and autonomous laboratory research.'
                : '具身智能测评、跨本体适配与自主实验室研发'}
            </p>

            <div className="flex items-center gap-4 justify-center flex-wrap">
              <Link to="/about"
                className="group inline-flex items-center gap-2 px-6 py-3 border border-foreground/30 hover:border-foreground/50 transition-all duration-300">
                <span className="text-[13px] text-foreground/70 group-hover:text-foreground transition-colors">
                  {lang === 'en' ? 'About the Lab' : '关于实验室'}
                </span>
                <ArrowUpRight size={12} className="text-foreground/40 group-hover:text-foreground/70 transition-colors" />
              </Link>
              <Link to="/about"
                className="group inline-flex items-center gap-2 px-6 py-3 border border-border hover:border-foreground/40 transition-all duration-300">
                <span className="text-[13px] text-foreground/60 group-hover:text-foreground transition-colors">
                  {lang === 'en' ? 'Collaborate' : '开展合作'}
                </span>
              </Link>
            </div>
          </div>
        </FadeInSection>
      </section>
    </div>
  );
}