import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';

const categories = [
  { path: '/research/publications', en: 'Publications', zh: '论文发表', desc_en: 'Peer-reviewed research papers at top AI and scientific venues.', desc_zh: '发表于顶级AI与科学期刊的同行评审论文。' },
  { path: '/research/patents', en: 'Patents', zh: '专利', desc_en: 'Inventions and intellectual property covering AI architectures, robotic systems, and environmental intelligence.', desc_zh: '涵盖AI架构、机器人系统与环境智能的发明专利与知识产权。' },
  { path: '/research/other-projects', en: 'Other Projects', zh: '其他项目', desc_en: 'Datasets, benchmarks, and products built from research.', desc_zh: '源自研究的数据集、评测基准与技术产品。' },
];

export default function Outputs() {
  const { lang } = useApp();

  return (
    <div className="overflow-x-hidden">
      <section className="pt-32 pb-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <p className="text-[13px] text-muted-foreground mb-4">{lang === 'en' ? 'What We Create' : '我们创造什么'}</p>
          <h1 className="text-[clamp(2.5rem,6vw,5rem)] font-bold tracking-tight leading-[0.95] mb-6">{lang === 'en' ? 'Research' : '研究'}</h1>
          <p className="text-[16px] text-foreground/60 max-w-xl leading-relaxed">
            {lang === 'en' ? 'Publications, patents, and projects — the tangible results of our research.' : '论文、专利与项目——我们研究的有形成果。'}
          </p>
        </FadeInSection>
      </section>

      <section className="py-10 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <div className="flex flex-col divide-y divide-border">
          {categories.map((c, i) => (
            <FadeInSection key={c.path} delay={i * 70}>
              <Link to={c.path}>
                <div className="group grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-6 lg:gap-16 py-10 hover:bg-foreground/[0.02] -mx-4 px-4 transition-colors cursor-pointer">
                  <div>
                    <h2 className="text-[clamp(1.3rem,2.5vw,2rem)] font-bold tracking-tight text-foreground/80 group-hover:text-foreground transition-colors mb-3">{lang === 'en' ? c.en : c.zh}</h2>
                    <p className="text-[14px] text-muted-foreground leading-relaxed max-w-2xl">{lang === 'en' ? c.desc_en : c.desc_zh}</p>
                  </div>
                  <div className="flex items-center gap-6">
                    <ArrowUpRight size={16} className="text-foreground/30 group-hover:text-foreground/60 transition-colors" />
                  </div>
                </div>
              </Link>
            </FadeInSection>
          ))}
        </div>
      </section>
    </div>
  );
}