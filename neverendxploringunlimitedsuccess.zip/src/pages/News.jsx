import React, { useState } from 'react';
import { useApp } from '@/lib/AppContext';
import { useI18n } from '@/lib/i18n';
import FadeInSection from '@/components/FadeInSection';
import MonoLabel from '@/components/MonoLabel';
import HorizonLine from '@/components/HorizonLine';
import { FileText, Mic, Calendar, Trophy, Radio, ExternalLink } from 'lucide-react';
import TableOfContents from '@/components/TableOfContents';

const tocSections = [
  { id: 'news-overview',      label_en: 'Overview',    label_zh: '概览' },
  { id: 'news-publications',  label_en: 'Publications',label_zh: '论文发表' },
  { id: 'news-awards',        label_en: 'Awards',      label_zh: '奖项' },
  { id: 'news-conferences',   label_en: 'Conferences', label_zh: '学术会议' },
  { id: 'news-events',        label_en: 'Events',      label_zh: '活动' },
  { id: 'news-media',         label_en: 'Media',       label_zh: '媒体报道' },
];

const newsData = [
  { date: 'June 2026', month: '2026-06', category: 'Publications', categoryZh: '论文发表', title: 'AetherEarth accepted at NeurIPS 2026', titleZh: 'AetherEarth论文被NeurIPS 2026录用', desc: 'Our flagship climate foundation model paper was accepted as an oral presentation at NeurIPS 2026.', descZh: '我们的旗舰气候基础模型论文被NeurIPS 2026接收为口头报告。', venue: 'NeurIPS 2026', icon: FileText },
  { date: 'May 2026', month: '2026-05', category: 'Awards', categoryZh: '奖项', title: 'Best Paper Award at ICLR 2026', titleZh: 'ICLR 2026最佳论文奖', desc: 'Received the Best Paper Award in the Embodied Intelligence track at ICLR 2026.', descZh: '在ICLR 2026物理智能赛道荣获最佳论文奖。', venue: 'ICLR 2026', icon: Trophy },
  { date: 'April 2026', month: '2026-04', category: 'Conferences', categoryZh: '学术会议', title: 'Keynote at CVPR 2026: Physical AI and Real-World Autonomy', titleZh: 'CVPR 2026主题演讲：物理AI与现实世界自主性', desc: 'Dr. Erik Garcia delivered a keynote address on embodied intelligence and physical AI systems.', descZh: '加西亚博士就物理智能和物理AI系统发表主题演讲。', venue: 'CVPR 2026', icon: Mic },
  { date: 'March 2026', month: '2026-03', category: 'Media', categoryZh: '媒体报道', title: 'Featured in Nature: "AI That Understands Earth"', titleZh: '《自然》杂志报道："理解地球的AI"', desc: 'Nature magazine features Aether Institute\'s climate AI research in a major cover story.', descZh: '《自然》杂志以封面故事形式报道穹境实验室的气候AI研究。', venue: 'Nature Magazine', icon: Radio },
  { date: 'February 2026', month: '2026-02', category: 'Events', categoryZh: '活动', title: 'Annual Symposium on Scientific AI — 200+ Attendees', titleZh: '科学AI年度研讨会——200余人参加', desc: 'Hosted the inaugural Aether Symposium on AI for Scientific Discovery, with 200+ researchers from 30 countries.', descZh: '主办首届穹境科学发现AI研讨会，来自30个国家的200余名研究人员参加。', venue: 'Aether Institute', icon: Calendar },
  { date: 'January 2026', month: '2026-01', category: 'Publications', categoryZh: '论文发表', title: 'Scaling Scientific Foundation Models — ICLR 2026', titleZh: '扩展科学基础模型——ICLR 2026', desc: 'New research on scaling laws for scientific foundation models, demonstrating emergent reasoning capabilities.', descZh: '关于科学基础模型扩展规律的新研究，展示了涌现推理能力。', venue: 'ICLR 2026', icon: FileText },
  { date: 'December 2025', month: '2025-12', category: 'Awards', categoryZh: '奖项', title: 'Nature Research Excellence Award 2025', titleZh: '2025年自然研究卓越奖', desc: 'Aether Institute receives the Nature Research Excellence Award for contributions to AI-driven climate science.', descZh: '穹境实验室因对AI驱动气候科学的贡献荣获自然研究卓越奖。', venue: 'Nature Portfolio', icon: Trophy },
  { date: 'November 2025', month: '2025-11', category: 'Conferences', categoryZh: '学术会议', title: 'Tutorial at NeurIPS 2025: Scientific AI Systems', titleZh: 'NeurIPS 2025教程：科学AI系统', desc: 'Half-day tutorial on building AI systems for scientific discovery, attended by 500+ participants.', descZh: '关于构建科学发现AI系统的半天教程，500余人参加。', venue: 'NeurIPS 2025', icon: Mic },
  { date: 'October 2025', month: '2025-10', category: 'Events', categoryZh: '活动', title: 'Aether Institute Officially Established', titleZh: '穹境智能实验室正式成立', desc: 'Aether Intelligence Institute formally inaugurated with a founding team of 20 world-class AI researchers.', descZh: '穹境智能实验室正式成立，由20位世界顶尖AI研究人员组成创始团队。', venue: 'Aether Institute', icon: Calendar },
];

const categoryIcons = {
  Publications: FileText,
  Conferences: Mic,
  Events: Calendar,
  Awards: Trophy,
  Media: Radio,
};

const categoryColors = {
  Publications: 'border-blue-500/30 text-blue-400 bg-blue-500/10',
  Conferences: 'border-violet-500/30 text-violet-400 bg-violet-500/10',
  Events: 'border-cyan-500/30 text-cyan-400 bg-cyan-500/10',
  Awards: 'border-amber-500/30 text-amber-400 bg-amber-500/10',
  Media: 'border-pink-500/30 text-pink-400 bg-pink-500/10',
};

export default function News() {
  const { lang } = useApp();
  const t = useI18n(lang);
  const [activeCategory, setActiveCategory] = useState('All');

  const enCats = ['All', 'Publications', 'Conferences', 'Events', 'Awards', 'Media'];
  const zhCats = ['全部', '论文发表', '学术会议', '活动', '奖项', '媒体报道'];
  const categories = lang === 'en' ? enCats : zhCats;

  const catMap = { '全部': 'All', '论文发表': 'Publications', '学术会议': 'Conferences', '活动': 'Events', '奖项': 'Awards', '媒体报道': 'Media' };
  const filterKey = lang === 'zh' ? (catMap[activeCategory] || activeCategory) : activeCategory;

  const filtered = filterKey === 'All' ? newsData : newsData.filter(n => n.category === filterKey);

  return (
    <div className="pt-24">
      <TableOfContents sections={tocSections} />
      <section id="news-overview" className="px-6 lg:px-10 py-20 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-4 block">{lang === 'en' ? 'Aether Intelligence Institute' : '穹境智能实验室'}</MonoLabel>
          <h1 className="text-[clamp(2.5rem,6vw,6rem)] font-bold tracking-tight mb-4">{t.newsPage.title}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">{t.newsPage.subtitle}</p>
        </FadeInSection>
      </section>

      <HorizonLine />

      <section className="px-6 lg:px-10 pb-24 max-w-[1400px] mx-auto">
        {/* Category filters */}
        <div className="flex flex-wrap gap-2 mb-12">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`mono-label text-[11px] px-4 py-2 rounded-full border transition-all min-h-[44px] ${
                activeCategory === cat
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border/50 text-muted-foreground hover:border-primary/40 hover:text-foreground'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Timeline — category section anchors */}
        {['publications', 'awards', 'conferences', 'events', 'media'].map(cat => (
          <div key={cat} id={`news-${cat}`} />
        ))}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-primary/40 via-primary/20 to-transparent ml-[7px] hidden sm:block" />

          <div className="space-y-8">
            {filtered.map((item, i) => {
              const Icon = item.icon;
              const catColor = categoryColors[item.category] || categoryColors.Publications;
              return (
                <FadeInSection key={i} delay={i * 60}>
                  <div className="flex gap-6">
                    {/* Timeline dot */}
                    <div className="hidden sm:flex flex-col items-center shrink-0 w-4 pt-1.5">
                      <div className="w-3.5 h-3.5 rounded-full bg-primary border-2 border-background ring-1 ring-primary/30 shrink-0" />
                    </div>

                    <div className="flex-1 group rounded-2xl border border-border/50 dark:bg-card/40 bg-card p-6 hover:border-primary/40 hover:shadow-md transition-all duration-300 cursor-pointer">
                      <div className="flex flex-wrap items-center gap-3 mb-3">
                        <span className="mono-label text-[10px] text-muted-foreground/60">{item.date}</span>
                        <span className={`inline-flex items-center gap-1.5 mono-label text-[10px] px-2.5 py-1 rounded-full border ${catColor}`}>
                          <Icon size={10} />
                          {lang === 'en' ? item.category : item.categoryZh}
                        </span>
                        <span className="mono-label text-[10px] text-muted-foreground/40">{item.venue}</span>
                      </div>
                      <h3 className="text-base font-semibold mb-2 group-hover:text-primary transition-colors">
                        {lang === 'en' ? item.title : item.titleZh}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {lang === 'en' ? item.desc : item.descZh}
                      </p>
                      <button className="mt-3 flex items-center gap-1 text-xs text-primary hover:underline min-h-[36px]">
                        {lang === 'en' ? 'Read more' : '阅读更多'} <ExternalLink size={11} />
                      </button>
                    </div>
                  </div>
                </FadeInSection>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}