import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';

const researchFocus = [
  { idx: '01', en_title: 'General AI', zh_title: '通用智能', en_desc: 'Large language model post-training, multimodal, Agentic RL, and intelligent agents.', zh_desc: '大模型后训练、多模态、Agentic RL与智能体' },
  { idx: '02', en_title: 'Embodied AI', zh_title: '具身智能', en_desc: 'World models, infra, cross-embodiment adaptation, and video generation.', zh_desc: '世界模型、Infra、跨本体适配与视频生成' },
  { idx: '03', en_title: 'Scientific AI', zh_title: '科学智能', en_desc: 'Autonomous laboratories and AI for chemistry, materials, and biology.', zh_desc: '自主实验室与化学、材料、生物等科研场景' },
];

const flowSteps = [
  { en: 'UAV', zh: '无人机' },
  { en: 'Industrial Robots', zh: '工业机器人' },
  { en: 'Autonomous Laboratories', zh: '自主实验室' },
  { en: 'General Modules', zh: '通用模块' },
];

export default function About() {
  const { lang } = useApp();
  const [pubCount, setPubCount] = useState(null);

  useEffect(() => {
    base44.entities.Publication.list('-created_date', 500)
      .then(data => setPubCount((data || []).length))
      .catch(() => setPubCount(null));
  }, []);

  const stats = [
    { n: pubCount ?? '—', label_en: 'Publications', label_zh: '论文' },
    { n: '9', label_en: 'Patents', label_zh: '专利' },
    { n: '12× H200', label_en: 'GPU Infrastructure', label_zh: 'GPU 算力' },
    { n: '8× A800', label_en: 'GPU Infrastructure', label_zh: 'GPU 算力' },
  ];

  return (
    <div className="overflow-x-hidden">
      {/* Hero */}
      <section className="pt-32 pb-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <h1 className="text-[clamp(2.2rem,5vw,4rem)] font-bold tracking-tight leading-[1.05] mb-8 max-w-3xl">
            {lang === 'en' ? 'Building Generalizable Embodied Intelligence.' : '构建通用具身智能基础设施。'}
          </h1>
          <p className="text-[15px] text-foreground/65 max-w-xl leading-relaxed">
            {lang === 'en'
              ? 'We focus on embodied intelligence evaluation, cross-embodiment adaptation, and autonomous laboratory technologies. Our goal is to advance AI from scenario-specific intelligence toward transferable and reusable general embodied intelligence.'
              : '我们聚焦于具身智能测评、跨本体适配与自主实验室技术研发，致力于推动人工智能从单一场景智能走向可迁移、可复用的通用具身智能。'}
          </p>
        </FadeInSection>
      </section>

      {/* Research Focus */}
      <section className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <h2 className="text-[clamp(1.8rem,4vw,3rem)] font-bold tracking-tight mb-14">{lang === 'en' ? 'Research Focus' : '研究方向'}</h2>
        </FadeInSection>

        <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-border">
          {researchFocus.map((r, i) => (
            <FadeInSection key={r.idx} delay={i * 80}>
              <div className="p-8 lg:p-10 flex flex-col gap-4">
                <span className="text-[12px] text-muted-foreground tabular-nums">{r.idx}</span>
                <h3 className="text-[18px] font-bold text-foreground/80">{lang === 'en' ? r.en_title : r.zh_title}</h3>
                <p className="text-[14px] text-foreground/70 leading-relaxed">{lang === 'en' ? r.en_desc : r.zh_desc}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      {/* From Scenarios to General Intelligence */}
      <section className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <h2 className="text-[clamp(1.8rem,4vw,3rem)] font-bold tracking-tight mb-14 max-w-2xl">
            {lang === 'en' ? 'From Scenarios to General Intelligence' : '从场景智能走向通用智能'}
          </h2>
        </FadeInSection>

        <FadeInSection delay={80}>
          <div className="flex flex-col md:flex-row items-stretch gap-2 md:gap-0">
            {flowSteps.map((s, i) => (
              <div key={i} className="flex items-center flex-1">
                <div className="flex-1 px-6 py-8">
                  <p className="text-[15px] font-medium text-foreground/85">{lang === 'en' ? s.en : s.zh}</p>
                </div>
                {i < flowSteps.length - 1 && (
                  <div className="hidden md:block w-px h-12 bg-border shrink-0" />
                )}
              </div>
            ))}
          </div>
        </FadeInSection>

        <FadeInSection delay={140}>
          <div className="mt-10 pt-6 border-t border-border">
            <p className="text-[15px] text-foreground/70 leading-relaxed max-w-xl">
              {lang === 'en' ? 'From validated scenarios to general embodied intelligence.' : '从已验证场景走向通用具身智能。'}
            </p>
          </div>
        </FadeInSection>
      </section>

      {/* Research & Infrastructure */}
      <section className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <h2 className="text-[clamp(1.8rem,4vw,3rem)] font-bold tracking-tight mb-14">{lang === 'en' ? 'Research & Infrastructure' : '研究基础'}</h2>
        </FadeInSection>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-border border border-border">
          {stats.map((s, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="bg-background p-8">
                <div className="text-[clamp(1.8rem,3vw,2.6rem)] font-bold tabular-nums text-foreground tracking-tight">{s.n}</div>
                <div className="text-[12px] text-muted-foreground mt-2">{lang === 'en' ? s.label_en : s.label_zh}</div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <div className="border border-border">
          <FadeInSection>
            <div className="p-8 flex flex-col gap-2">
              <span className="text-[12px] text-muted-foreground">{lang === 'en' ? 'Address' : '地址'}</span>
              <span className="text-[15px] text-foreground/85 leading-relaxed">{lang === 'en' ? 'Room 1404, Resource East Building, Peking University, No.5 Yiheyuan Road, Haidian District, Beijing' : '北京市海淀区颐和园路5号北京大学资源东楼1404'}</span>
            </div>
          </FadeInSection>
        </div>
      </section>
    </div>
  );
}