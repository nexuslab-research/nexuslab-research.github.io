import React from 'react';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';
import MonoLabel from '@/components/MonoLabel';
import HorizonLine from '@/components/HorizonLine';
import TableOfContents from '@/components/TableOfContents';
import { Globe, ChevronRight, FileText, Database, ExternalLink } from 'lucide-react';

const tocSections = [
  { id: 'pi-overview',      label_en: 'Overview',         label_zh: '概览' },
  { id: 'pi-problems',      label_en: 'Key Problems',     label_zh: '核心问题' },
  { id: 'pi-projects',      label_en: 'Projects',         label_zh: '研究项目' },
  { id: 'pi-publications',  label_en: 'Publications',     label_zh: '论文' },
  { id: 'pi-datasets',      label_en: 'Datasets',         label_zh: '数据集' },
  { id: 'pi-models',        label_en: 'Models',           label_zh: '模型' },
  { id: 'pi-applications',  label_en: 'Applications',     label_zh: '应用' },
];

const problems = [
  { en: 'Accurate long-range climate prediction under nonlinear atmospheric dynamics', zh: '非线性大气动力学下的精确长期气候预测' },
  { en: 'Modeling ocean-atmosphere coupling at global and regional scales', zh: '全球与区域尺度的海-气耦合建模' },
  { en: 'Real-time ecosystem health assessment from heterogeneous sensor data', zh: '异构传感器数据的实时生态系统健康评估' },
  { en: 'Uncertainty quantification for high-impact extreme weather events', zh: '高影响极端天气事件的不确定性量化' },
  { en: 'Integrating multi-modal Earth observation into unified AI representations', zh: '将多模态地球观测融合为统一AI表征' },
];

const projects = [
  { name: 'AetherEarth', status: 'Active', en: 'A 100B-parameter foundation model trained on 50 years of global atmospheric, oceanic, and terrestrial data for multi-scale Earth system simulation.', zh: '基于50年全球大气、海洋和陆地数据训练的1000亿参数基础模型，用于多尺度地球系统模拟。' },
  { name: 'OceanMind', status: 'Active', en: 'Deep reinforcement learning system for real-time ocean current prediction and anomaly detection using satellite altimetry and Argo float data.', zh: '利用卫星测高和Argo浮标数据进行实时海流预测和异常检测的深度强化学习系统。' },
  { name: 'EcoSense', status: 'Active', en: 'Multi-modal ecosystem health monitoring platform combining satellite imagery, ground sensors, and climate reanalysis for biodiversity assessment.', zh: '结合卫星图像、地面传感器和气候再分析数据的多模态生态系统健康监测平台。' },
];

const publications = [
  { title: 'AetherEarth: Unified Foundation Model for Earth System Modeling', venue: 'NeurIPS 2026', year: '2026', authors: 'Zhang, L. · Chen, M. · Park, J. et al.' },
  { title: 'Neural Climate Simulators with Uncertainty Quantification', venue: 'Nature Machine Intelligence', year: '2026', authors: 'Park, J. · Zhang, L. · Kim, Y.' },
  { title: 'Probabilistic Ocean State Estimation with Diffusion Models', venue: 'ICML 2026', year: '2026', authors: 'Liu, R. · Nguyen, T.' },
  { title: 'Deep Learning for Ecosystem Biodiversity Prediction', venue: 'Nature Computational Science', year: '2025', authors: 'Aoki, S. · Liu, R.' },
];

const datasets = [
  { name: 'AetherClimate-50', size: '2.4 TB', access: 'Open', en: '50 years of global climate reanalysis at 0.1° resolution.', zh: '0.1°分辨率的50年全球气候再分析数据。' },
  { name: 'OceanDepth-HD', size: '890 GB', access: 'Open', en: 'High-resolution deep ocean observations from 1000+ buoys.', zh: '来自1000余个浮标的高分辨率深海观测数据。' },
  { name: 'EcoSat-2M', size: '3.1 TB', access: 'Restricted', en: '2M satellite image patches with ecosystem health labels.', zh: '带有生态系统健康标签的200万张卫星图像块。' },
];

const models = [
  { name: 'AetherEarth-100B', type: 'Foundation Model', en: 'Earth system foundation model, 100B params. Available via API.', zh: '地球系统基础模型，1000亿参数，可通过API访问。' },
  { name: 'ClimateForge-Predictor', type: 'Forecasting', en: '10-day ensemble weather forecasting model for operational use.', zh: '用于业务化运行的10天集成天气预报模型。' },
  { name: 'OceanNet-RL', type: 'Reinforcement Learning', en: 'RL-based ocean current prediction and anomaly detection system.', zh: '基于强化学习的海流预测与异常检测系统。' },
];

const applications = [
  { en: 'Operational climate forecasting for governments and research institutions', zh: '面向政府与研究机构的业务化气候预报' },
  { en: 'Agricultural yield prediction and drought early warning systems', zh: '农业产量预测与干旱预警系统' },
  { en: 'Renewable energy site assessment and generation forecasting', zh: '可再生能源选址评估与发电量预测' },
  { en: 'Marine ecosystem protection and fishery management support', zh: '海洋生态系统保护与渔业管理支持' },
  { en: 'Disaster risk assessment for extreme weather events', zh: '极端天气事件灾害风险评估' },
];

export default function ResearchPlanet() {
  const { lang } = useApp();

  return (
    <div className="pt-24">
      <TableOfContents sections={tocSections} />

      {/* Header */}
      <section id="pi-overview" className="px-6 lg:px-10 py-20 max-w-[1400px] mx-auto">
        <FadeInSection>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 border border-blue-500/25 bg-blue-500/10 mb-8">
            <Globe size={13} className="text-blue-400" />
            <MonoLabel className="text-[10px] text-blue-400">
              {lang === 'en' ? 'Planet Intelligence' : '环境智能'}
            </MonoLabel>
          </div>
          <h1 className="text-[clamp(2.5rem,6vw,6rem)] font-bold tracking-tight mb-4">
            {lang === 'en' ? 'Planet Intelligence' : '环境智能'}
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            {lang === 'en'
              ? 'AI systems that perceive, model, and predict Earth\'s climate, ocean, and ecological systems at planetary scale — enabling humanity to understand and protect our biosphere.'
              : '在行星尺度上感知、建模和预测地球气候、海洋与生态系统的AI系统——使人类能够理解并保护我们的生物圈。'}
          </p>
        </FadeInSection>
      </section>

      <HorizonLine />

      {/* Key Problems */}
      <section id="pi-problems" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Key Problems' : '核心问题'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Scientific Challenges' : '科学挑战'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-border/20">
          {problems.map((p, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="bg-background p-8 hover:bg-foreground/[0.02] transition-colors">
                <MonoLabel className="text-[9px] text-blue-400/60 mb-3 block">{String(i + 1).padStart(2, '0')}</MonoLabel>
                <p className="text-[14px] text-foreground/75 leading-relaxed">
                  {lang === 'en' ? p.en : p.zh}
                </p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Research Projects */}
      <section id="pi-projects" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Research Projects' : '研究项目'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Active Projects' : '活跃项目'}
          </h2>
        </FadeInSection>
        <div className="space-y-4">
          {projects.map((proj, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-blue-500/15 hover:border-blue-500/35 transition-all p-8 cursor-pointer">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-lg font-semibold group-hover:text-blue-400 transition-colors">{proj.name}</h3>
                      <span className="mono-label text-[9px] px-2 py-0.5 border border-green-500/25 bg-green-500/10 text-green-400">{proj.status}</span>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{lang === 'en' ? proj.en : proj.zh}</p>
                  </div>
                  <ChevronRight size={16} className="text-foreground/20 group-hover:text-blue-400 transition-colors ml-6 mt-1 shrink-0" />
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Publications */}
      <section id="pi-publications" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Publications' : '学术论文'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Selected Papers' : '代表性论文'}
          </h2>
        </FadeInSection>
        <div className="divide-y divide-border/20">
          {publications.map((pub, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="group flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 py-6 hover:bg-foreground/[0.02] -mx-4 px-4 transition-colors cursor-pointer">
                <MonoLabel className="text-[9px] text-foreground/25 sm:w-40 shrink-0">{pub.venue}</MonoLabel>
                <div className="flex-1">
                  <h3 className="text-[14px] font-medium text-foreground/80 group-hover:text-foreground transition-colors mb-1">{pub.title}</h3>
                  <p className="text-[11px] text-foreground/35">{pub.authors}</p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <MonoLabel className="text-[9px] text-foreground/20">{pub.year}</MonoLabel>
                  <span className="mono-label text-[10px] text-foreground/30 group-hover:text-foreground/60 transition-colors"><FileText size={12} /></span>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Datasets */}
      <section id="pi-datasets" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Datasets' : '数据集'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Open Data & Benchmarks' : '开放数据与基准'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {datasets.map((ds, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-blue-500/30 transition-all p-6 flex flex-col h-full">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold group-hover:text-blue-400 transition-colors">{ds.name}</h3>
                  <span className={`mono-label text-[9px] px-2 py-0.5 border shrink-0 ml-2 ${ds.access === 'Open' ? 'border-green-500/25 text-green-400 bg-green-500/10' : 'border-amber-500/25 text-amber-400 bg-amber-500/10'}`}>
                    {ds.access}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground flex-1 mb-4">{lang === 'en' ? ds.en : ds.zh}</p>
                <div className="flex items-center justify-between">
                  <MonoLabel className="text-[9px] text-foreground/30">{ds.size}</MonoLabel>
                  <button className="flex items-center gap-1 text-xs text-blue-400 hover:underline"><ExternalLink size={11} /> {lang === 'en' ? 'Access' : '访问'}</button>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Models */}
      <section id="pi-models" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Models' : 'AI模型'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Released Models' : '已发布模型'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {models.map((m, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-blue-500/30 transition-all p-6">
                <MonoLabel className="text-[9px] text-blue-400/60 mb-3 block">{m.type}</MonoLabel>
                <h3 className="font-mono font-semibold mb-3 group-hover:text-blue-400 transition-colors">{m.name}</h3>
                <p className="text-sm text-muted-foreground">{lang === 'en' ? m.en : m.zh}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Applications */}
      <section id="pi-applications" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Applications' : '应用场景'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Real-World Impact' : '现实世界影响'}
          </h2>
        </FadeInSection>
        <div className="space-y-px bg-border/20">
          {applications.map((app, i) => (
            <FadeInSection key={i} delay={i * 50}>
              <div className="flex items-center gap-6 bg-background px-8 py-6 hover:bg-foreground/[0.02] transition-colors">
                <MonoLabel className="text-[9px] text-blue-400/50 w-6 shrink-0">{String(i + 1).padStart(2, '0')}</MonoLabel>
                <p className="text-[14px] text-foreground/70">{lang === 'en' ? app.en : app.zh}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>
    </div>
  );
}