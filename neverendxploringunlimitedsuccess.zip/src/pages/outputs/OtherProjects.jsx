import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';
import ImageLightbox from '@/components/ImageLightbox';
import WatermarkedImage from '@/components/WatermarkedImage';

// Bilingual labels for gallery groups (Chinese → English)
const LABEL_EN = {
  'AI识别系统和土地管理': 'AI Recognition System & Land Management',
  '生产厂家情况': 'Manufacturer Overview',
};

export default function OtherProjects() {
  const { lang } = useApp();
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lightboxImage, setLightboxImage] = useState(null);

  useEffect(() => {
    base44.entities.ProductImage.list('-created_date', 200)
      .then(data => setImages(data || []))
      .catch(() => setImages([]))
      .finally(() => setLoading(false));
  }, []);

  // Group images by the leading label (strip trailing digits)
  const groups = useMemo(() => {
    const map = new Map();
    images.forEach(img => {
      const base = (img.name || '').replace(/\d+$/, '').trim() || (img.name || '未命名');
      if (!map.has(base)) map.set(base, []);
      map.get(base).push(img);
    });
    return Array.from(map.entries()).map(([label, items]) => {
      const sorted = items.slice().sort((a, b) => {
        const ma = (String(a.name || '').match(/(\d+)$/)) || ['0', '0'];
        const mb = (String(b.name || '').match(/(\d+)$/)) || ['0', '0'];
        return parseInt(ma[1], 10) - parseInt(mb[1], 10);
      });
      return { label, items: sorted };
    });
  }, [images]);

  const flat = useMemo(() => groups.flatMap(g => g.items), [groups]);

  return (
    <div className="overflow-x-hidden">
      {/* Hero */}
      <section className="pt-32 pb-16 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <h1 className="text-[clamp(2rem,5vw,4rem)] font-bold tracking-tight leading-[0.95]">
            {lang === 'en' ? 'Evaluation & Products' : '评测与产品'}
          </h1>
        </FadeInSection>
      </section>

      {/* Gallery */}
      <section className="py-10 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        {loading ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-6 h-6 border-2 border-border border-t-foreground/40 rounded-full animate-spin" />
          </div>
        ) : flat.length === 0 ? (
          <div className="py-24 text-center">
            <p className="text-[14px] text-muted-foreground">{lang === 'en' ? 'No content yet.' : '暂无内容。'}</p>
          </div>
        ) : (
          <div className="flex flex-col gap-12">
            {groups.map((group, gi) => (
              <FadeInSection key={group.label} delay={gi * 80}>
                <div>
                  <div className="flex items-center gap-3 mb-6">
                    <h2 className="text-[clamp(1.2rem,2.5vw,1.8rem)] font-bold tracking-tight text-foreground/80">
                      {lang === 'en' && LABEL_EN[group.label] ? LABEL_EN[group.label] : group.label}
                    </h2>
                    <div className="flex-1 h-px bg-border" />
                    <span className="text-[12px] text-muted-foreground">{group.items.length} {lang === 'en' ? (group.items.length === 1 ? 'image' : 'images') : '张'}</span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {group.items.map((img, i) => {
                      return (
                        <button
                          key={img.id}
                          onClick={() => setLightboxImage(img)}
                          className="group relative aspect-[4/3] overflow-hidden border border-border hover:border-foreground/30 transition-colors bg-foreground/5 p-0"
                        >
                          <WatermarkedImage
                            src={img.file_url}
                            caption={img.name}
                            className="w-full h-full"
                          />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </FadeInSection>
            ))}
          </div>
        )}
      </section>

      {lightboxImage && (
        <ImageLightbox
          image={lightboxImage}
          onClose={() => setLightboxImage(null)}
        />
      )}
    </div>
  );
}