import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';

export default function PublicationDetail() {
  const { id } = useParams();
  const { lang } = useApp();
  const [pub, setPub] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    base44.entities.Publication.get(id)
      .then(data => {
        if (data) setPub(data);
        else setNotFound(true);
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="pt-40 pb-20 px-6 lg:px-10 max-w-[900px] mx-auto">
        <div className="w-6 h-6 border-2 border-border border-t-foreground/40 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (notFound || !pub) {
    return (
      <div className="pt-40 pb-20 px-6 lg:px-10 max-w-[900px] mx-auto">
        <p className="text-muted-foreground">{lang === 'en' ? 'Publication not found.' : '未找到该论文。'}</p>
        <Link to="/research/publications" className="text-[13px] text-foreground/60 hover:text-foreground mt-4 inline-block">
          ← {lang === 'en' ? 'Back to Publications' : '返回论文列表'}
        </Link>
      </div>
    );
  }

  const metadata = [
    { label_en: 'Authors', label_zh: '作者', value: pub.authors },
    { label_en: 'Year', label_zh: '日期', value: pub.year },
    { label_en: 'Venue', label_zh: '发表载体', value: pub.venue },
    { label_en: 'Volume', label_zh: '卷号', value: pub.volume },
    { label_en: 'Issue', label_zh: '期号', value: pub.issue },
    { label_en: 'Pages', label_zh: '页码', value: pub.pages },
  ].filter(m => m.value);

  return (
    <div className="overflow-x-hidden">
      <section className="pt-32 pb-16 px-6 lg:px-10 max-w-[900px] mx-auto">
        <FadeInSection>
          <div className="mb-10">
            <Link to="/research/publications" className="text-[13px] text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5">
              <ArrowLeft size={12} /> {lang === 'en' ? 'Publications' : '论文发表'}
            </Link>
          </div>

          {pub.website_page ? (
            <a href={pub.website_page} target="_blank" rel="noopener noreferrer" className="block">
              <h1 className="text-[clamp(1.5rem,3.5vw,2.5rem)] font-bold tracking-tight leading-[1.2] mb-8 text-foreground hover:opacity-80 transition-opacity">
                {pub.title}
              </h1>
            </a>
          ) : (
            <h1 className="text-[clamp(1.5rem,3.5vw,2.5rem)] font-bold tracking-tight leading-[1.2] mb-8 text-foreground">
              {pub.title}
            </h1>
          )}


        </FadeInSection>

        {metadata.length > 0 && (
          <FadeInSection delay={60}>
            <div className="space-y-4 mb-12 border-t border-border pt-8">
              {metadata.map((m, i) => (
                <div key={i} className="flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-8">
                  <span className="text-[12px] text-muted-foreground sm:w-24 shrink-0 pt-0.5">
                    {lang === 'en' ? m.label_en : m.label_zh}
                  </span>
                  <p className="text-[14px] text-foreground/80 leading-relaxed flex-1">{m.value}</p>
                </div>
              ))}
            </div>
          </FadeInSection>
        )}

        {pub.abstract && (
          <FadeInSection delay={100}>
            <div className="border-t border-border pt-8">
              <p className="text-[12px] text-muted-foreground mb-3">
                {lang === 'en' ? 'Abstract' : '摘要'}
              </p>
              <p className="text-[15px] text-foreground/80 leading-[1.8]">{pub.abstract}</p>
            </div>
          </FadeInSection>
        )}
      </section>
    </div>
  );
}