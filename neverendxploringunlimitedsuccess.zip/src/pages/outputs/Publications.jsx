import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Search, X, ArrowDownNarrowWide, ArrowUpNarrowWide } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';

export default function Publications() {
  const { lang } = useApp();
  const [pubs, setPubs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');
  const [activeYear, setActiveYear] = useState('all');
  const [sortAsc, setSortAsc] = useState(false);

  useEffect(() => {
    base44.entities.Publication.list('-created_date', 500)
      .then(data => { if (data) setPubs(data); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const normYear = (v) => {
    const m = String(v || '').match(/\d{4}/);
    return m ? m[0] : (v ? String(v) : '未知');
  };

  const years = useMemo(() => {
    const set = new Set();
    pubs.forEach(p => { if (p.year) set.add(normYear(p.year)); });
    return Array.from(set).filter(y => /^\d{4}$/.test(y)).sort((a, b) => b.localeCompare(a));
  }, [pubs]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return pubs;
    const terms = q.split(/\s+/).filter(Boolean);
    const score = (p) => {
      const fields = [
        { v: (p.title || '').toLowerCase(), w: 3 },
        { v: (p.authors || '').toLowerCase(), w: 2 },
        { v: (p.abstract || '').toLowerCase(), w: 1 },
        { v: (p.venue || '').toLowerCase(), w: 1 },
      ];
      let s = 0;
      terms.forEach(t => {
        fields.forEach(f => { if (f.v.includes(t)) s += f.w; });
      });
      return s;
    };
    return pubs
      .map(p => ({ p, s: score(p) }))
      .filter(x => x.s > 0)
      .sort((a, b) => b.s - a.s)
      .map(x => x.p);
  }, [pubs, query]);

  const grouped = useMemo(() => {
    const list = activeYear === 'all'
      ? filtered
      : filtered.filter(p => normYear(p.year) === String(activeYear));
    const groups = {};
    list.forEach(p => {
      const y = normYear(p.year);
      if (!groups[y]) groups[y] = [];
      groups[y].push(p);
    });
    const dir = sortAsc ? 1 : -1;
    return Object.keys(groups)
      .sort((a, b) => dir * a.localeCompare(b))
      .map(y => ({
        year: y,
        items: groups[y].slice().sort((a, b) => dir * String(a.year || '').localeCompare(String(b.year || ''))),
      }));
  }, [filtered, activeYear, sortAsc]);

  const totalShown = grouped.reduce((n, g) => n + g.items.length, 0);

  return (
    <div className="overflow-x-hidden">
      <section className="pt-32 pb-16 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <h1 className="text-[clamp(2rem,5vw,4rem)] font-bold tracking-tight leading-[0.95]">{lang === 'en' ? 'Publications' : '论文发表'}</h1>
        </FadeInSection>
      </section>

      <section className="py-10 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <div className="flex flex-col gap-5 mb-10">
            <div className="relative max-w-xl">
              <Search size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder={lang === 'en' ? 'Search by title, author, abstract…' : '搜索论文名、作者、摘要……'}
                className="w-full pl-11 pr-10 py-3 bg-background border border-border focus:border-foreground/40 outline-none text-[14px] text-foreground placeholder:text-muted-foreground transition-colors"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label="clear"
                >
                  <X size={16} />
                </button>
              )}
            </div>

            {years.length > 0 && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setActiveYear('all')}
                  className={`text-[13px] px-3 py-1.5 border transition-colors ${
                    activeYear === 'all'
                      ? 'border-foreground/50 text-foreground bg-foreground/5'
                      : 'border-border text-muted-foreground hover:text-foreground hover:border-foreground/30'
                  }`}
                >
                  {lang === 'en' ? 'All' : '全部'}
                </button>
                {years.map(y => (
                  <button
                    key={y}
                    onClick={() => setActiveYear(y)}
                    className={`text-[13px] px-3 py-1.5 border tabular-nums transition-colors ${
                      String(activeYear) === String(y)
                        ? 'border-foreground/50 text-foreground bg-foreground/5'
                        : 'border-border text-muted-foreground hover:text-foreground hover:border-foreground/30'
                    }`}
                  >
                    {y}
                  </button>
                ))}
              </div>
            )}

            <div className="flex items-center justify-between gap-3">
              <span className="text-[12px] text-muted-foreground">
                {totalShown} {lang === 'en' ? (totalShown === 1 ? 'result' : 'results') : '条结果'}
              </span>
              <button
                onClick={() => setSortAsc(v => !v)}
                className="flex items-center gap-1.5 text-[13px] px-3 py-1.5 border border-border text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
                title={lang === 'en' ? (sortAsc ? 'Newest first' : 'Oldest first') : (sortAsc ? '最新优先' : '最早优先')}
              >
                {sortAsc ? <ArrowUpNarrowWide size={14} /> : <ArrowDownNarrowWide size={14} />}
                {lang === 'en' ? (sortAsc ? 'Oldest first' : 'Newest first') : (sortAsc ? '最早优先' : '最新优先')}
              </button>
            </div>
          </div>
        </FadeInSection>

        {loading ? (
          <div className="flex items-center justify-center py-24">
            <div className="w-6 h-6 border-2 border-border border-t-foreground/40 rounded-full animate-spin" />
          </div>
        ) : grouped.length === 0 ? (
          <div className="py-24 text-center">
            <p className="text-[14px] text-muted-foreground">{query ? (lang === 'en' ? 'No related content found.' : '没有相关内容。') : (lang === 'en' ? 'No publications found.' : '暂无论文。')}</p>
          </div>
        ) : (
          grouped.map((group) => (
            <div key={group.year} className="mb-12">
              <FadeInSection>
                <div className="flex items-center gap-3 mb-5">
                  <span className="text-[15px] font-semibold text-foreground/70 tabular-nums">{group.year}</span>
                  <div className="flex-1 h-px bg-border" />
                  <span className="text-[12px] text-muted-foreground">{group.items.length} {lang === 'en' ? 'papers' : '篇'}</span>
                </div>
              </FadeInSection>
              <div className="divide-y divide-border">
                {group.items.map((p, i) => (
                  <FadeInSection key={p.id || i} delay={i * 30}>
                    <div className="group flex flex-col sm:flex-row sm:items-start gap-4 sm:gap-8 py-6 hover:bg-foreground/[0.02] -mx-4 px-4 transition-colors">
                      <div className="flex-1">
                        <Link to={`/research/publications/${p.id}`}>
                          <h3 className="text-[15px] font-medium text-foreground/85 group-hover:text-foreground transition-colors leading-snug mb-2">{p.title}</h3>
                        </Link>
                        {p.authors && <p className="text-[12px] text-muted-foreground mb-2">{p.authors}</p>}
                        {p.year && <span className="text-[12px] text-muted-foreground tabular-nums">{p.year}</span>}
                      </div>

                    </div>
                  </FadeInSection>
                ))}
              </div>
            </div>
          ))
        )}
      </section>
    </div>
  );
}