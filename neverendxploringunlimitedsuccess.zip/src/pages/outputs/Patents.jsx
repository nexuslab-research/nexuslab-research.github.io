import React from 'react';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';

const ALL_PATENTS = [
  { number: '2025108602252', title: '基于代码仓库图结构的图表征学习、检索的方法和系统', date: '2025-06-25', country: '中国', inventors: '崇滨 · 杨英光 · 吴媚 · 龙慧超 · 张子逸 · 焦思齐' },
  { number: '2025107807787', title: '基于双分支网络架构的跨模态适配微调方法和系统', date: '2025-06-12', country: '中国', inventors: '崇滨 · 杨英光 · 吴媚 · 何鸿彬 · 戴弘毅 · 焦思齐' },
  { number: '2025118483353', title: '一键式土地智能识别与分割方法及系统', date: '2025-12-09', country: '中国', inventors: '崇滨 · 姚朝乾 · 焦思齐 · 张子逸 · 何鸿彬' },
  { number: '2025118553534', title: '一种储备土地可供应地块筛选方法及系统', date: '2025-12-10', country: '中国', inventors: '崇滨 · 何鸿彬 · 焦思齐 · 张子逸 · 姚朝乾' },
];

export default function Patents() {
  const { lang } = useApp();

  const sorted = [...ALL_PATENTS].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div className="overflow-x-hidden">
      <section className="pt-32 pb-16 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <h1 className="text-[clamp(2rem,5vw,4rem)] font-bold tracking-tight leading-[0.95]">{lang === 'en' ? 'Patents & IP' : '专利与知识产权'}</h1>
        </FadeInSection>
      </section>

      <section className="py-10 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sorted.map((p, i) => (
            <FadeInSection key={i} delay={i * 50}>
              <div className="border border-border p-6 flex flex-col gap-3 hover:border-foreground/30 transition-colors">
                <span className="text-[12px] text-muted-foreground tabular-nums">{p.number}</span>
                <h3 className="text-[15px] font-medium text-foreground/80 leading-snug">{p.title}</h3>
                <p className="text-[12px] text-muted-foreground">{p.inventors}</p>
                <div className="flex flex-wrap gap-2 mt-auto pt-2">
                  <span className="text-[11px] border border-border text-muted-foreground px-2 py-0.5 tabular-nums">{p.date}</span>
                  <span className="text-[11px] border border-border text-muted-foreground px-2 py-0.5">{p.country}</span>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>
    </div>
  );
}