import React from 'react';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';
import MonoLabel from '@/components/MonoLabel';
import HorizonLine from '@/components/HorizonLine';
import TableOfContents from '@/components/TableOfContents';
import { Cpu, ChevronRight, FileText, Database, ExternalLink } from 'lucide-react';

const tocSections = [
  { id: 'gi-overview',    label_en: 'Overview',           label_zh: '概览' },
  { id: 'gi-foundation',  label_en: 'Foundation Models',  label_zh: '基础模型' },
  { id: 'gi-agents',      label_en: 'AI Agents',          label_zh: 'AI智能体' },
  { id: 'gi-ml-systems',  label_en: 'ML Systems',         label_zh: '机器学习系统' },
  { id: 'gi-computing',   label_en: 'Scientific Computing',label_zh: '科学计算' },
  { id: 'gi-benchmarks',  label_en: 'Benchmarks',         label_zh: '基准测试' },
  { id: 'gi-datasets',    label_en: 'Datasets',           label_zh: '数据集' },
  { id: 'gi-publications',label_en: 'Publications',       label_zh: '论文' },
];

const foundationModels = [
  { name: 'AetherGPT-Science', params: '147B', en: 'Scientific reasoning foundation model pre-trained on 10M research papers across 12 scientific disciplines. State-of-the-art on BenchSci.', zh: '在12个科学学科的1000万篇研究论文上预训练的科学推理基础模型，在BenchSci上达到最先进水平。' },
  { name: 'AetherGPT-Code', params: '34B', en: 'Scientific code generation model specialized in numerical computing, simulation, and data analysis workflows.', zh: '专注于数值计算、仿真和数据分析工作流的科学代码生成模型。' },
  { name: 'AetherEmbed-Science', params: '7B', en: 'Dense retrieval model for scientific literature, enabling semantic search across 10M+ papers with sub-second latency.', zh: '科学文献稠密检索模型，支持1000万余篇论文的语义搜索，延迟低于1秒。' },
];

const agents = [
  { name: 'AgentScope', en: 'Multi-agent framework for collaborative scientific hypothesis generation, experiment design, and result interpretation.', zh: '用于协作科学假设生成、实验设计和结果解释的多智能体框架。' },
  { name: 'LitReview Agent', en: 'Autonomous agent capable of summarizing, critiquing, and synthesizing scientific literature for any given research topic.', zh: '能够对任意研究主题的科学文献进行摘要、评述和综合的自主智能体。' },
  { name: 'Experiment Planner', en: 'AI system that proposes experimental protocols and resource requirements given a scientific hypothesis.', zh: '给定科学假设后提出实验方案和资源需求的AI系统。' },
];

const mlSystems = [
  { en: 'Distributed training infrastructure for 1000+ GPU clusters', zh: '支持1000余块GPU集群的分布式训练基础设施' },
  { en: 'Custom CUDA kernels for scientific attention mechanisms', zh: '面向科学注意力机制的自定义CUDA内核' },
  { en: 'Efficient inference serving with <100ms p99 latency at scale', zh: '大规模推理服务，p99延迟低于100毫秒' },
  { en: 'Automated hyperparameter optimization for scientific tasks', zh: '科学任务的自动超参数优化' },
];

const computing = [
  { en: 'Neural solvers for partial differential equations in physics simulations', zh: '物理仿真中偏微分方程的神经求解器' },
  { en: 'AI-accelerated molecular dynamics and quantum chemistry', zh: 'AI加速分子动力学与量子化学' },
  { en: 'Symbolic regression for discovering physical laws from data', zh: '从数据中发现物理定律的符号回归' },
  { en: 'Differentiable programming for physics-informed neural networks', zh: '物理信息神经网络的可微编程' },
];

const benchmarks = [
  { name: 'BenchSci-Core', tasks: '12', en: 'Core scientific reasoning benchmark across 12 disciplines: physics, chemistry, biology, earth science, and more.', zh: '涵盖物理、化学、生物、地球科学等12个学科的核心科学推理基准。' },
  { name: 'BenchSci-Math', tasks: '5', en: 'Advanced mathematical reasoning tasks including theorem proving, symbolic computation, and numerical analysis.', zh: '包括定理证明、符号计算和数值分析的高级数学推理任务。' },
  { name: 'SciCode-Eval', tasks: '8', en: 'Code generation benchmark for scientific computing tasks in Python, Julia, and MATLAB.', zh: 'Python、Julia和MATLAB科学计算任务的代码生成基准。' },
];

const datasets = [
  { name: 'SciPaper-10M', size: '1.8 TB', access: 'Restricted', en: '10M scientific papers with structured knowledge graph annotations and citation networks.', zh: '带有结构化知识图谱标注和引文网络的1000万篇科学论文。' },
  { name: 'BenchSci-Core', size: '8 GB', access: 'Open', en: 'Comprehensive scientific reasoning benchmark across 12 disciplines.', zh: '涵盖12个学科的综合科学推理基准。' },
  { name: 'SciCode-300K', size: '45 GB', access: 'Open', en: '300K scientific code snippets with docstrings, tests, and execution traces.', zh: '带有文档字符串、测试和执行轨迹的30万个科学代码片段。' },
];

const publications = [
  { title: 'Scaling Scientific Foundation Models Beyond 100B Parameters', venue: 'NeurIPS 2026', year: '2026', authors: 'Wang, H. · Garcia, E. · Kim, Y. · Aoki, S.' },
  { title: 'Agentic Scientific Discovery with Tool-Augmented Reasoning', venue: 'ICLR 2026', year: '2026', authors: 'Kim, Y. · Zhang, L.' },
  { title: 'BenchSci: A Comprehensive Benchmark for Scientific AI Evaluation', venue: 'NeurIPS 2025', year: '2025', authors: 'Chen, M. · Wang, H.' },
  { title: 'Neural Solvers for Parametric PDEs at Scale', venue: 'ICML 2026', year: '2026', authors: 'Garcia, E. · Park, J.' },
];

export default function ResearchGeneral() {
  const { lang } = useApp();

  return (
    <div className="pt-24">
      <TableOfContents sections={tocSections} />

      {/* Header */}
      <section id="gi-overview" className="px-6 lg:px-10 py-20 max-w-[1400px] mx-auto">
        <FadeInSection>
          <div className="inline-flex items-center gap-2 px-3 py-1.5 border border-cyan-500/25 bg-cyan-500/10 mb-8">
            <Cpu size={13} className="text-cyan-400" />
            <MonoLabel className="text-[10px] text-cyan-400">
              {lang === 'en' ? 'General Intelligence' : '通用智能'}
            </MonoLabel>
          </div>
          <h1 className="text-[clamp(2.5rem,6vw,6rem)] font-bold tracking-tight mb-4">
            {lang === 'en' ? 'General Intelligence' : '通用智能'}
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl leading-relaxed">
            {lang === 'en'
              ? 'Foundation models and reasoning architectures that unify scientific knowledge across domains — enabling AI agents capable of open-ended scientific discovery.'
              : '统一跨领域科学知识的基础模型与推理架构——支持能够进行开放式科学发现的AI智能体。'}
          </p>
        </FadeInSection>
      </section>

      <HorizonLine />

      {/* Foundation Models */}
      <section id="gi-foundation" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Foundation Models' : '基础模型'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Scientific Foundation Models' : '科学基础模型'}
          </h2>
        </FadeInSection>
        <div className="space-y-4">
          {foundationModels.map((m, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-cyan-500/15 hover:border-cyan-500/35 transition-all p-8">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-mono font-semibold text-lg group-hover:text-cyan-400 transition-colors">{m.name}</h3>
                      <span className="mono-label text-[9px] px-2 py-0.5 border border-cyan-500/25 bg-cyan-500/10 text-cyan-400">{m.params}</span>
                    </div>
                    <p className="text-muted-foreground leading-relaxed">{lang === 'en' ? m.en : m.zh}</p>
                  </div>
                  <ChevronRight size={16} className="text-foreground/20 group-hover:text-cyan-400 transition-colors ml-6 mt-1 shrink-0" />
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* AI Agents */}
      <section id="gi-agents" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'AI Agents' : 'AI智能体'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Autonomous Scientific Agents' : '自主科学智能体'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {agents.map((a, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-cyan-500/30 transition-all p-6 h-full">
                <h3 className="font-semibold mb-3 group-hover:text-cyan-400 transition-colors">{a.name}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{lang === 'en' ? a.en : a.zh}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* ML Systems */}
      <section id="gi-ml-systems" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Machine Learning Systems' : '机器学习系统'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Infrastructure & Systems' : '基础设施与系统'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border/20">
          {mlSystems.map((s, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="bg-background p-7 hover:bg-foreground/[0.02] transition-colors">
                <div className="flex items-start gap-4">
                  <MonoLabel className="text-[9px] text-cyan-400/60 shrink-0 mt-0.5">{String(i + 1).padStart(2, '0')}</MonoLabel>
                  <p className="text-[14px] text-foreground/70 leading-relaxed">{lang === 'en' ? s.en : s.zh}</p>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Scientific Computing */}
      <section id="gi-computing" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Scientific Computing' : '科学计算'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'AI for Scientific Computation' : 'AI驱动的科学计算'}
          </h2>
        </FadeInSection>
        <div className="space-y-px bg-border/20">
          {computing.map((c, i) => (
            <FadeInSection key={i} delay={i * 50}>
              <div className="flex items-center gap-6 bg-background px-8 py-6 hover:bg-foreground/[0.02] transition-colors">
                <MonoLabel className="text-[9px] text-cyan-400/50 w-6 shrink-0">{String(i + 1).padStart(2, '0')}</MonoLabel>
                <p className="text-[14px] text-foreground/70">{lang === 'en' ? c.en : c.zh}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Benchmarks */}
      <section id="gi-benchmarks" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Benchmarks' : '基准测试'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Evaluation Benchmarks' : '评估基准'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {benchmarks.map((b, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-cyan-500/30 transition-all p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-mono font-semibold group-hover:text-cyan-400 transition-colors">{b.name}</h3>
                  <span className="mono-label text-[9px] px-2 py-0.5 border border-cyan-500/25 bg-cyan-500/10 text-cyan-400 shrink-0 ml-2">{b.tasks} tasks</span>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">{lang === 'en' ? b.en : b.zh}</p>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Datasets */}
      <section id="gi-datasets" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Datasets' : '数据集'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Data & Resources' : '数据与资源'}
          </h2>
        </FadeInSection>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {datasets.map((ds, i) => (
            <FadeInSection key={i} delay={i * 80}>
              <div className="group border border-border/40 hover:border-cyan-500/30 transition-all p-6 flex flex-col h-full">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-mono font-semibold group-hover:text-cyan-400 transition-colors">{ds.name}</h3>
                  <span className={`mono-label text-[9px] px-2 py-0.5 border shrink-0 ml-2 ${ds.access === 'Open' ? 'border-green-500/25 text-green-400 bg-green-500/10' : 'border-amber-500/25 text-amber-400 bg-amber-500/10'}`}>
                    {ds.access}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground flex-1 mb-4 leading-relaxed">{lang === 'en' ? ds.en : ds.zh}</p>
                <div className="flex items-center justify-between">
                  <MonoLabel className="text-[9px] text-foreground/30">{ds.size}</MonoLabel>
                  <button className="flex items-center gap-1 text-xs text-cyan-400 hover:underline"><ExternalLink size={11} /> {lang === 'en' ? 'Access' : '访问'}</button>
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>

      <HorizonLine />

      {/* Publications */}
      <section id="gi-publications" className="py-20 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-6 block text-foreground/35">{lang === 'en' ? 'Publications' : '学术论文'}</MonoLabel>
          <h2 className="text-[clamp(1.5rem,3vw,2.5rem)] font-bold tracking-tight mb-10">
            {lang === 'en' ? 'Selected Papers' : '代表性论文'}
          </h2>
        </FadeInSection>
        <div className="divide-y divide-border/20">
          {publications.map((pub, i) => (
            <FadeInSection key={i} delay={i * 60}>
              <div className="group flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-8 py-6 hover:bg-foreground/[0.02] -mx-4 px-4 transition-colors cursor-pointer">
                <MonoLabel className="text-[9px] text-foreground/25 sm:w-40 shrink-0">{pub.venue}</MonoLabel>
                <div className="flex-1">
                  <h3 className="text-[14px] font-medium text-foreground/80 group-hover:text-foreground transition-colors mb-1">{pub.title}</h3>
                  <p className="text-[11px] text-foreground/35">{pub.authors}</p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <MonoLabel className="text-[9px] text-foreground/20">{pub.year}</MonoLabel>
                  <FileText size={12} className="text-foreground/25 group-hover:text-foreground/50 transition-colors" />
                </div>
              </div>
            </FadeInSection>
          ))}
        </div>
      </section>
    </div>
  );
}