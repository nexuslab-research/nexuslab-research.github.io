import React, { useState } from 'react';
import { useApp } from '@/lib/AppContext';
import { useI18n } from '@/lib/i18n';
import FadeInSection from '@/components/FadeInSection';
import MonoLabel from '@/components/MonoLabel';
import HorizonLine from '@/components/HorizonLine';
import TableOfContents from '@/components/TableOfContents';
import { ArrowRight, Play, Cpu, Globe, Zap, BarChart3 } from 'lucide-react';

const tocSections = [
  { id: 'prod-overview',      label_en: 'Overview',      label_zh: '概览' },
  { id: 'prod-drone',         label_en: 'Drone Intel',   label_zh: '无人机智能' },
  { id: 'prod-climateforge',  label_en: 'ClimateForge',  label_zh: '气候锻造' },
  { id: 'prod-aether-agent',  label_en: 'AetherAgent',   label_zh: '科学智能体' },
  { id: 'prod-manufacturing', label_en: 'Manufacturing', label_zh: '智能制造' },
];

const products = [
  {
    id: 'drone',
    nameEn: 'Aether Drone Intelligence',
    nameZh: '穹境无人机智能系统',
    tagEn: 'Embodied AI',
    tagZh: '物理AI',
    descEn: 'AI-powered autonomous drone intelligence system for environmental monitoring, infrastructure inspection, and precision agriculture. Powered by our DroneForge neural architecture.',
    descZh: 'AI驱动的自主无人机智能系统，用于环境监测、基础设施检测和精准农业。由我们的DroneForge神经架构驱动。',
    featsEn: ['Real-time obstacle avoidance', 'Multi-drone swarm coordination', 'On-edge AI inference', 'Environmental sensor fusion'],
    featsZh: ['实时障碍物避让', '多无人机集群协调', '边缘端AI推理', '环境传感器融合'],
    statsEn: [{ v: '99.7%', l: 'Autonomy Rate' }, { v: '<20ms', l: 'Inference Latency' }, { v: '8 hrs', l: 'Flight Duration' }],
    statsZh: [{ v: '99.7%', l: '自主率' }, { v: '<20ms', l: '推理延迟' }, { v: '8小时', l: '飞行时长' }],
    icon: Zap,
    color: 'from-violet-600 to-purple-700',
    glow: 'violet',
    bg: 'from-violet-950/40 to-purple-950/40',
    bgLight: 'from-violet-50 to-purple-50',
  },
  {
    id: 'climateforge',
    nameEn: 'ClimateForge',
    nameZh: '气候锻造平台',
    tagEn: 'Planet AI',
    tagZh: '环境AI',
    descEn: 'AI-driven climate simulation and prediction platform for research institutions, governments, and enterprises. Provides granular 10-day forecasts and 100-year projections.',
    descZh: 'AI驱动的气候模拟和预测平台，面向研究机构、政府和企业。提供精细的10天预报和100年预测。',
    featsEn: ['0.1° spatial resolution', 'Ensemble uncertainty estimates', 'Extreme event prediction', 'API & dashboard access'],
    featsZh: ['0.1°空间分辨率', '集成不确定性估计', '极端事件预测', 'API与仪表板访问'],
    statsEn: [{ v: '0.1°', l: 'Resolution' }, { v: '95%', l: 'Forecast Accuracy' }, { v: '100yr', l: 'Projection Range' }],
    statsZh: [{ v: '0.1°', l: '分辨率' }, { v: '95%', l: '预测精度' }, { v: '100年', l: '预测范围' }],
    icon: Globe,
    color: 'from-blue-600 to-cyan-700',
    glow: 'blue',
    bg: 'from-blue-950/40 to-cyan-950/40',
    bgLight: 'from-blue-50 to-cyan-50',
  },
  {
    id: 'aether-agent',
    nameEn: 'AetherAgent',
    nameZh: '穹境科学智能体',
    tagEn: 'General AI',
    tagZh: '通用AI',
    descEn: 'A general-purpose scientific reasoning AI agent capable of literature review, hypothesis generation, experiment design, and result interpretation.',
    descZh: '通用科学推理AI智能体，能够进行文献综述、假设生成、实验设计和结果解释。',
    featsEn: ['10M paper knowledge base', 'Multi-step reasoning', 'Tool-augmented research', 'Natural language interface'],
    featsZh: ['1000万论文知识库', '多步推理', '工具增强研究', '自然语言接口'],
    statsEn: [{ v: '10M+', l: 'Papers Indexed' }, { v: '94%', l: 'Reasoning Score' }, { v: '12+', l: 'Disciplines' }],
    statsZh: [{ v: '1000万+', l: '索引论文' }, { v: '94%', l: '推理得分' }, { v: '12+', l: '学科领域' }],
    icon: Cpu,
    color: 'from-cyan-600 to-teal-700',
    glow: 'cyan',
    bg: 'from-cyan-950/40 to-teal-950/40',
    bgLight: 'from-cyan-50 to-teal-50',
  },
  {
    id: 'manufacturing',
    nameEn: 'Manufacturing AI Suite',
    nameZh: '智能制造AI套件',
    tagEn: 'Embodied AI',
    tagZh: '物理AI',
    descEn: 'End-to-end AI for intelligent manufacturing — from process optimization and quality inspection to predictive maintenance and supply chain intelligence.',
    descZh: '端到端智能制造AI——从工艺优化和质量检验到预测性维护和供应链智能。',
    featsEn: ['Real-time process optimization', 'Vision-based quality inspection', 'Predictive maintenance', 'Digital twin integration'],
    featsZh: ['实时工艺优化', '基于视觉的质量检验', '预测性维护', '数字孪生集成'],
    statsEn: [{ v: '35%', l: 'Defect Reduction' }, { v: '28%', l: 'Energy Savings' }, { v: '99.2%', l: 'Uptime' }],
    statsZh: [{ v: '35%', l: '缺陷减少' }, { v: '28%', l: '节能' }, { v: '99.2%', l: '运行时间' }],
    icon: BarChart3,
    color: 'from-amber-600 to-orange-700',
    glow: 'amber',
    bg: 'from-amber-950/40 to-orange-950/40',
    bgLight: 'from-amber-50 to-orange-50',
  },
];

export default function Products() {
  const { lang, theme } = useApp();
  const t = useI18n(lang);
  const [selected, setSelected] = useState(null);

  const glowColors = {
    violet: 'shadow-violet-500/15',
    blue: 'shadow-blue-500/15',
    cyan: 'shadow-cyan-500/15',
    amber: 'shadow-amber-500/15',
  };

  const borderColors = {
    violet: 'border-violet-500/25',
    blue: 'border-blue-500/25',
    cyan: 'border-cyan-500/25',
    amber: 'border-amber-500/25',
  };

  return (
    <div className="pt-24">
      <TableOfContents sections={tocSections} />

      <section id="prod-overview" className="px-6 lg:px-10 py-20 max-w-[1400px] mx-auto">
        <FadeInSection>
          <MonoLabel className="mb-4 block">{lang === 'en' ? 'Technology Products' : '技术产品'}</MonoLabel>
          <h1 className="text-[clamp(2.5rem,6vw,6rem)] font-bold tracking-tight mb-4">{t.productsPage.title}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl">{t.productsPage.subtitle}</p>
        </FadeInSection>
      </section>

      <HorizonLine />

      <section className="px-6 lg:px-10 pb-24 max-w-[1400px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {products.map((prod, i) => {
            const Icon = prod.icon;
            const isOpen = selected === prod.id;
            return (
              <FadeInSection key={prod.id} delay={i * 100}>
                <div id={`prod-${prod.id}`}
                  className={`group rounded-3xl border ${borderColors[prod.glow]} overflow-hidden hover:shadow-2xl ${glowColors[prod.glow]} transition-all duration-500 cursor-pointer dark:bg-card/40 bg-card`}
                  onClick={() => setSelected(isOpen ? null : prod.id)}
                >
                  {/* Product Header */}
                  <div className={`relative p-8 dark:bg-gradient-to-br ${prod.bg} bg-gradient-to-br ${prod.bgLight} overflow-hidden`}>
                    <div className="absolute inset-0 opacity-30">
                      <div className={`absolute top-0 right-0 w-64 h-64 bg-gradient-to-br ${prod.color} rounded-full blur-3xl opacity-30`} />
                    </div>
                    <div className="relative z-10 flex items-start justify-between">
                      <div>
                        <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${prod.color} flex items-center justify-center mb-4 shadow-lg`}>
                          <Icon size={26} className="text-white" />
                        </div>
                        <span className="mono-label text-[10px] text-white/60 dark:text-white/60 text-foreground/50 mb-2 block">
                          {lang === 'en' ? prod.tagEn : prod.tagZh}
                        </span>
                        <h2 className="text-2xl font-bold dark:text-white text-foreground">
                          {lang === 'en' ? prod.nameEn : prod.nameZh}
                        </h2>
                      </div>
                      <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center">
                        <ArrowRight size={14} className={`text-white/60 transition-transform duration-300 ${isOpen ? 'rotate-90' : ''}`} />
                      </div>
                    </div>

                    {/* Stats row */}
                    <div className="grid grid-cols-3 gap-3 mt-6">
                      {(lang === 'en' ? prod.statsEn : prod.statsZh).map((stat, si) => (
                        <div key={si} className="rounded-xl bg-white/10 backdrop-blur-sm p-3 text-center">
                          <p className="text-xl font-bold dark:text-white text-foreground">{stat.v}</p>
                          <p className="mono-label text-[9px] dark:text-white/50 text-foreground/50 mt-0.5">{stat.l}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expanded Details */}
                  <div className={`overflow-hidden transition-all duration-500 ${isOpen ? 'max-h-[500px]' : 'max-h-0'}`}>
                    <div className="p-8 border-t border-border/40">
                      <p className="text-muted-foreground mb-6 leading-relaxed">
                        {lang === 'en' ? prod.descEn : prod.descZh}
                      </p>
                      <div>
                        <p className="mono-label text-[11px] text-primary mb-3">
                          {lang === 'en' ? 'Key Features' : '核心功能'}
                        </p>
                        <ul className="space-y-2">
                          {(lang === 'en' ? prod.featsEn : prod.featsZh).map((f, fi) => (
                            <li key={fi} className="flex items-center gap-3 text-sm text-muted-foreground">
                              <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                              {f}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="flex gap-3 mt-6">
                        <button className="flex items-center gap-2 px-5 py-3 bg-primary text-primary-foreground rounded-xl text-sm font-medium hover:opacity-90 transition-opacity min-h-[44px]">
                          {lang === 'en' ? 'Request Demo' : '申请演示'} <ArrowRight size={14} />
                        </button>
                        <button className="flex items-center gap-2 px-5 py-3 border border-border/60 rounded-xl text-sm text-muted-foreground hover:text-foreground hover:border-primary/40 transition-all min-h-[44px]">
                          <Play size={14} /> {lang === 'en' ? 'Watch Video' : '观看视频'}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Collapsed hint */}
                  {!isOpen && (
                    <div className="px-8 py-4 border-t border-border/30">
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {lang === 'en' ? prod.descEn : prod.descZh}
                      </p>
                    </div>
                  )}
                </div>
              </FadeInSection>
            );
          })}
        </div>
      </section>
    </div>
  );
}