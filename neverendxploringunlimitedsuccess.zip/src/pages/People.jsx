import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useApp } from '@/lib/AppContext';
import FadeInSection from '@/components/FadeInSection';

// Team leader bio — kept on the page (not synced), per provided text.
const LEADER_NAME = '崇滨';
const LEADER_TITLE = '团队负责人';
const LEADER_BIO = `国家工程实验室特聘副研究员，北京大学理学博士，清华大学博士后。在机器学习，知识图谱，大模型等领域发表三十余篇SCI和CCF-A 类会议论文。曾在匹兹堡大学，MIT斯隆管理学院，台湾大学，哈佛大学交流访问。主持和参与973计划，国家自然科学基金重点和面上项目，省部级课题。入选北京市青年人才托举工程、北京大学产学研合作奖、苏州市慧湖领创计划，先后参与企业数字化转型、全球数字人才和数字技能发展、数据跨境智能合规等报告和专著撰写，获相关部门采纳和领导批示。`;
const LEADER_RESEARCH = '研究方向：大模型、知识图谱、Agentic AI、通用具身';

export default function People() {
  const { lang } = useApp();
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.TeamMember.list('-created_date', 200)
      .then(data => setMembers(data || []))
      .catch(() => setMembers([]))
      .finally(() => setLoading(false));
  }, []);

  const leader = members.find(m => (m.name || '').includes(LEADER_NAME));
  const others = members
    .filter(m => m !== leader)
    .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'zh-Hans-CN'));

  return (
    <div className="overflow-x-hidden">
      <div className="pt-32 pb-12 px-6 lg:px-10 max-w-[1400px] mx-auto">
        <FadeInSection>
          <p className="text-[13px] text-muted-foreground mb-4">{lang === 'en' ? 'The Team' : '团队成员'}</p>
          <h1 className="text-[clamp(2.5rem,6vw,5rem)] font-bold tracking-tight leading-[0.95]">
            {lang === 'en' ? 'People' : '团队成员'}
          </h1>
        </FadeInSection>
      </div>

      {/* Leader */}
      <section className="py-16 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <p className="text-[13px] text-muted-foreground mb-8">{lang === 'en' ? 'Lead' : '团队负责人'}</p>
        </FadeInSection>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-border border-t-foreground/40 rounded-full animate-spin" />
          </div>
        ) : leader ? (
          <FadeInSection delay={60}>
            <div className="flex flex-col md:flex-row gap-10">
              <div className="w-full md:w-[280px] shrink-0">
                <div className="aspect-[4/5] w-full overflow-hidden border border-border bg-foreground/5">
                  <img
                    src={leader.file_url}
                    alt={leader.name}
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="flex-1 flex flex-col">
                <div className="flex items-baseline gap-3 mb-1">
                  <h2 className="text-[clamp(1.6rem,3vw,2.2rem)] font-bold tracking-tight text-foreground">{leader.name}</h2>
                  <span className="text-[13px] text-muted-foreground">{LEADER_TITLE}</span>
                </div>
                <p className="text-[14px] text-foreground/70 leading-relaxed mt-6 max-w-2xl">{LEADER_BIO}</p>
                <p className="text-[13px] text-foreground/60 leading-relaxed mt-5 max-w-2xl">{LEADER_RESEARCH}</p>
              </div>
            </div>
          </FadeInSection>
        ) : (
          <div className="py-20 text-center">
            <p className="text-[14px] text-muted-foreground">{lang === 'en' ? 'No data.' : '暂无数据。'}</p>
          </div>
        )}
      </section>

      {/* Other members */}
      <section className="py-16 px-6 lg:px-10 max-w-[1400px] mx-auto border-t border-border">
        <FadeInSection>
          <div className="flex items-center gap-4 mb-10">
            <h2 className="text-[1.6rem] font-bold tracking-tight">{lang === 'en' ? 'Members' : '团队成员'}</h2>
            <span className="text-[13px] text-muted-foreground ml-auto">
              {others.length} {lang === 'en' ? 'members' : '人'}
            </span>
          </div>
        </FadeInSection>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-6 h-6 border-2 border-border border-t-foreground/40 rounded-full animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-3">
            {others.map((p, i) => (
              <FadeInSection key={p.id} delay={Math.min(i * 50, 400)}>
                <div className="group flex flex-col border border-border hover:border-foreground/30 transition-colors">
                  <div className="aspect-[4/5] w-full overflow-hidden bg-foreground/5">
                    <img
                      src={p.file_url}
                      alt={p.name}
                      loading="lazy"
                      className="w-full h-full object-cover grayscale-[0.15] group-hover:grayscale-0 transition-all duration-500"
                    />
                  </div>
                  <div className="px-4 py-3 border-t border-border">
                    <h3 className="text-[15px] font-medium text-foreground/80 group-hover:text-foreground transition-colors leading-snug">
                      {p.name}
                    </h3>
                  </div>
                </div>
              </FadeInSection>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}