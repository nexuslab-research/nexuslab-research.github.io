import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { AppProvider } from '@/lib/AppContext';
import Layout from '@/components/Layout';

import Home from '@/pages/Home';
import Publications from '@/pages/outputs/Publications';
import PublicationDetail from '@/pages/outputs/PublicationDetail';
import Patents from '@/pages/outputs/Patents';
import OtherProjects from '@/pages/outputs/OtherProjects';
import People from '@/pages/People';
import About from '@/pages/About';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin"></div>
          <span className="text-[12px] text-muted-foreground">加载中</span>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') return <UserNotRegisteredError />;
    if (authError.type === 'auth_required') { navigateToLogin(); return null; }
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/research/publications" element={<Publications />} />
        <Route path="/research/publications/:id" element={<PublicationDetail />} />
        <Route path="/research/patents" element={<Patents />} />
        <Route path="/research/other-projects" element={<OtherProjects />} />
        <Route path="/people" element={<People />} />
        <Route path="/about" element={<About />} />

      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <AppProvider>
          <Router>
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </AppProvider>
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;