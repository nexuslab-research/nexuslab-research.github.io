import React, { useId } from 'react';

export default function NexusLogo({ size = 24, className = '' }) {
  const gradId = useId();
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id={gradId} x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stopColor="#0D2C5E" />
          <stop offset="100%" stopColor="#B0B5B8" />
        </linearGradient>
      </defs>
      <rect x="5" y="5" width="9" height="30" rx="1" fill="#0D2C5E" />
      <rect x="26" y="5" width="9" height="30" rx="1" fill={`url(#${gradId})`} />
      <path d="M14 35 L22 35 L26 5 L18 5 Z" fill={`url(#${gradId})`} />
      <path d="M14 7 Q20 20 26 33" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" opacity="0.85" />
    </svg>
  );
}