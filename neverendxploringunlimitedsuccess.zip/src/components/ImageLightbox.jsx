import React, { useEffect } from 'react';
import { X } from 'lucide-react';

/**
 * ImageLightbox — full-screen modal for enlarged image viewing.
 * Displays the image with a NEXUS LAB watermark and caption.
 */
export default function ImageLightbox({ image, onClose }) {
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handleKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  if (!image) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-6 lg:p-12"
      style={{ background: 'rgba(0,0,0,0.92)', backdropFilter: 'blur(8px)' }}
      onClick={onClose}
    >
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-6 right-6 w-10 h-10 flex items-center justify-center border border-foreground/15 text-foreground/40 hover:text-foreground hover:border-foreground/30 transition-colors"
      >
        <X size={16} />
      </button>

      {/* Image container */}
      <div
        className="relative max-w-[90vw] max-h-[85vh] flex flex-col items-center"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
          <img
            src={image.file_url}
            alt={image.name}
            className="max-w-[90vw] max-h-[78vh] object-contain"
          />
          {/* Watermark — logo */}
          <img
            src="https://media.base44.com/images/public/6a2be9d0fafad4f8e6783c4f/5cb39edd6_logo.png"
            alt="NEXUS LAB"
            className="absolute bottom-4 right-4 h-12 w-auto pointer-events-none select-none"
            style={{ opacity: 0.85, mixBlendMode: 'screen', filter: 'drop-shadow(0 2px 6px rgba(0,0,0,0.8))' }}
          />
        </div>

        {/* Caption */}
        {image.name && (
          <p className="mt-4 mono-label text-[9px] text-foreground/40 tracking-[0.15em] text-center">
            {image.name}
          </p>
        )}
      </div>
    </div>
  );
}