import React from 'react';

export default function MonoLabel({ children, className = '' }) {
  return (
    <span className={`mono-label text-primary/70 ${className}`}>
      {children}
    </span>
  );
}