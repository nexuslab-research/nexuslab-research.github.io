import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

/**
 * ArchiveEntry — Scientific database entry card.
 * Styled like a future civilization's research archive record.
 * Inspired by: NASA mission logs, scientific specimen labels,
 * and spatial glass interface panels.
 */
export default function ArchiveEntry({ 
  entryId, 
  field, 
  status, 
  title, 
  subtitle,
  tags = [],
  href,
  accentColor = '190,210,255',
  className = ''
}) {
  const content = (
    <div className={`group relative border border-foreground/8 hover:border-foreground/20 transition-all duration-500 overflow-hidden ${className}`}
      style={{
        background: 'linear-gradient(135deg, rgba(255,255,255,0.02) 0%, rgba(255,255,255,0.005) 100%)',
        backdropFilter: 'blur(12px)',
      }}
    >
      {/* Top scan line effect */}
      <div className="absolute top-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-700"
        style={{ background: `linear-gradient(90deg, transparent, rgba(${accentColor},0.4), transparent)` }}
      />

      <div className="p-6 flex flex-col gap-4 h-full">
        {/* Header row */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex flex-col gap-1">
            <span className="mono-label text-[8px] text-foreground/25 tracking-[0.18em]">
              ARCHIVE · {entryId}
            </span>
            {field && (
              <span className="mono-label text-[8px] tracking-[0.12em]"
                style={{ color: `rgba(${accentColor},0.7)` }}>
                FIELD: {field.toUpperCase()}
              </span>
            )}
          </div>
          {status && (
            <div className="flex items-center gap-1.5 shrink-0">
              <div className="w-1 h-1 rounded-full animate-pulse"
                style={{ background: `rgba(${accentColor},0.8)` }}
              />
              <span className="mono-label text-[7px] text-foreground/30 tracking-[0.1em]">{status.toUpperCase()}</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1">
          <h3 className="text-[13px] font-medium text-foreground/70 group-hover:text-foreground/90 transition-colors leading-snug mb-1.5">
            {title}
          </h3>
          {subtitle && (
            <p className="text-[11px] text-foreground/35 leading-relaxed">{subtitle}</p>
          )}
        </div>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {tags.map((tag, i) => (
              <span key={i} className="mono-label text-[7px] px-2 py-0.5 border text-foreground/30 border-foreground/8 tracking-[0.08em]">
                {tag.toUpperCase()}
              </span>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-foreground/6 pt-3 mt-1">
          <div className="flex gap-3">
            <div className="w-6 h-px" style={{ background: `rgba(${accentColor},0.3)` }} />
            <div className="w-3 h-px" style={{ background: `rgba(${accentColor},0.15)` }} />
          </div>
          <ArrowUpRight size={11} className="text-foreground/15 group-hover:text-foreground/45 transition-colors" />
        </div>
      </div>

      {/* Corner accent */}
      <div className="absolute bottom-0 right-0 w-8 h-8 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
        <div className="absolute bottom-0 right-0 w-full h-px" style={{ background: `rgba(${accentColor},0.3)` }} />
        <div className="absolute bottom-0 right-0 w-px h-full" style={{ background: `rgba(${accentColor},0.3)` }} />
      </div>
    </div>
  );

  if (href) return <Link to={href}>{content}</Link>;
  return content;
}