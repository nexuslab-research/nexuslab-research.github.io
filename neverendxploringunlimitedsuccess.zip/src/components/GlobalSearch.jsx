import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Search, X, ArrowRight } from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import { searchContent } from '@/lib/searchIndex';

export default function GlobalSearch() {
  const { lang } = useApp();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef(null);
  const overlayRef = useRef(null);

  useEffect(() => {
    const handler = e => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setOpen(v => !v);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 60);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      setQuery('');
      setResults([]);
      setActiveIdx(0);
    }
  }, [open]);

  const handleQuery = useCallback(e => {
    const q = e.target.value;
    setQuery(q);
    setActiveIdx(0);
    setResults(q.trim().length > 0 ? searchContent(q, lang) : []);
  }, [lang]);

  const handleKeyDown = e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActiveIdx(i => Math.min(i + 1, results.length - 1)); }
    if (e.key === 'ArrowUp')   { e.preventDefault(); setActiveIdx(i => Math.max(i - 1, 0)); }
    if (e.key === 'Enter' && results[activeIdx]) setOpen(false);
  };

  const placeholderText = lang === 'en'
    ? 'Search research, papers, people, products…'
    : '搜索研究方向、论文、团队、产品……';

  const emptyLabel = lang === 'en' ? 'No results found.' : '未找到相关结果。';
  const hintLabel  = lang === 'en'
    ? 'Try: "climate", "foundation model", "drone"'
    : '试试："气候"、"基础模型"、"无人机"';

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        aria-label="Search"
        className="flex items-center gap-2 text-[12px] text-foreground/60 hover:text-foreground border border-border hover:border-foreground/30 px-3 py-1.5 transition-all duration-200"
      >
        <Search size={13} className="shrink-0" />
        <span className="hidden xl:block">{lang === 'en' ? 'Search' : '搜索'}</span>
        <kbd className="hidden xl:block text-[10px] text-muted-foreground font-mono">⌘K</kbd>
      </button>
    );
  }

  return (
    <div
      ref={overlayRef}
      className="fixed inset-0 z-[100] flex flex-col items-center pt-[12vh] px-4"
      style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(8px)' }}
      onClick={e => { if (e.target === overlayRef.current) setOpen(false); }}
    >
      <div className="w-full max-w-2xl bg-background border border-border shadow-2xl">
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border">
          <Search size={14} className="text-muted-foreground shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={handleQuery}
            onKeyDown={handleKeyDown}
            placeholder={placeholderText}
            className="flex-1 bg-transparent text-[14px] text-foreground placeholder:text-muted-foreground outline-none"
          />
          <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground transition-colors p-1">
            <X size={14} />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto">
          {query.trim().length === 0 ? (
            <div className="px-5 py-10 text-center">
              <p className="text-[12px] text-muted-foreground mb-2">
                {lang === 'en' ? 'Start typing to search' : '输入关键词开始搜索'}
              </p>
              <p className="text-[11px] text-muted-foreground/70">{hintLabel}</p>
            </div>
          ) : results.length === 0 ? (
            <div className="px-5 py-10 text-center">
              <p className="text-[13px] text-muted-foreground">{emptyLabel}</p>
            </div>
          ) : (
            <div className="py-1.5">
              {results.map((item, i) => {
                const title = lang === 'zh' ? item.title_zh : item.title_en;
                const desc  = lang === 'zh' ? item.desc_zh  : item.desc_en;
                const cat   = lang === 'zh' ? item.category_zh : item.category_en;
                const isActive = i === activeIdx;
                return (
                  <Link
                    key={item.id}
                    to={item.path}
                    onClick={() => setOpen(false)}
                    onMouseEnter={() => setActiveIdx(i)}
                    className={`flex items-start gap-4 px-5 py-3.5 cursor-pointer transition-colors ${
                      isActive ? 'bg-foreground/[0.04]' : 'hover:bg-foreground/[0.025]'
                    }`}
                  >
                    <span className="text-[11px] text-muted-foreground mt-0.5 w-20 shrink-0 truncate">
                      {cat}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-medium text-foreground/85 leading-snug truncate">{title}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{desc}</p>
                    </div>
                    <ArrowRight size={11} className="text-muted-foreground shrink-0 mt-1" />
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {results.length > 0 && (
          <div className="border-t border-border px-5 py-2 flex items-center gap-4">
            <span className="text-[10px] text-muted-foreground">↑↓ {lang === 'en' ? 'navigate' : '导航'}</span>
            <span className="text-[10px] text-muted-foreground">↵ {lang === 'en' ? 'open' : '打开'}</span>
            <span className="text-[10px] text-muted-foreground">ESC {lang === 'en' ? 'close' : '关闭'}</span>
          </div>
        )}
      </div>
    </div>
  );
}