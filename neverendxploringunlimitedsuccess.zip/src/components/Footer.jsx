import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '@/lib/AppContext';
import NexusLogo from '@/components/NexusLogo';

export default function Footer() {
  const { lang } = useApp();

  return (
    <footer className="mt-auto border-t border-border">
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-3">
              <NexusLogo size={18} className="shrink-0" />
              <p className="text-[13px] font-semibold text-foreground/80">Nexus Lab</p>
            </div>
            <p className="text-[13px] text-muted-foreground max-w-xs leading-relaxed mb-2">
              {lang === 'en'
                ? 'One Mind, Many Embodiments.'
                : '一脑多形，智能无界'}
            </p>
            <p className="text-[13px] text-muted-foreground max-w-xs leading-relaxed">
              {lang === 'en'
                ? 'Embodied intelligence evaluation, cross-embodiment adaptation, and autonomous laboratory research.'
                : '具身智能测评、跨本体适配与自主实验室研发'}
            </p>
          </div>
          <div>
            <p className="text-[12px] text-muted-foreground mb-4">{lang === 'en' ? 'Explore' : '探索'}</p>
            <div className="flex flex-col gap-2.5">
              {[
                { path: '/research/publications', en: 'Publications',   zh: '论文发表' },
                { path: '/research/patents',       en: 'Patents',         zh: '专利' },
                { path: '/research/other-projects', en: 'Other Projects', zh: '评测与产品' },
                { path: '/people',                 en: 'People',         zh: '团队成员' },
                { path: '/about',                  en: 'About',          zh: '关于我们' },
              ].map(l => (
                <Link key={l.path} to={l.path} className="text-[13px] text-foreground/60 hover:text-foreground transition-colors">
                  {lang === 'en' ? l.en : l.zh}
                </Link>
              ))}
            </div>
          </div>
          <div>
            <p className="text-[12px] text-muted-foreground mb-4">{lang === 'en' ? 'Contact' : '联系我们'}</p>
            <p className="text-[13px] text-foreground/60 leading-relaxed max-w-xs">
              {lang === 'en'
                ? 'Room 1404, Resource East Building, Peking University, No.5 Yiheyuan Road, Haidian District, Beijing'
                : '北京市海淀区颐和园路5号北京大学资源东楼1404'}
            </p>
          </div>
        </div>
        <div className="border-t border-border pt-6">
          <p className="text-[11px] text-muted-foreground">© 2026 Nexus Lab</p>
        </div>
      </div>
    </footer>
  );
}