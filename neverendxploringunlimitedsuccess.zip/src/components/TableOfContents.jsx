import React, { useState, useEffect, useRef } from 'react';
import { List, X, ChevronDown } from 'lucide-react';
import { useApp } from '@/lib/AppContext';

/**
 * TableOfContents
 *
 * Props:
 *   sections: Array<{ id: string, label_en: string, label_zh: string }>
 *
 * Usage:
 *   1. Add id="section-id" to each section element in the page.
 *   2. Pass sections array to this component.
 *   3. Place this outside the scrollable content — it positions itself fixed.
 */
export default function TableOfContents({ sections = [] }) {
  const { lang } = useApp();
  const [activeId, setActiveId] = useState(sections[0]?.id || '');
  const [mobileOpen, setMobileOpen] = useState(false);
  const observerRef = useRef(null);

  useEffect(() => {
    if (sections.length === 0) return;

    // IntersectionObserver to detect active section
    const targets = sections
      .map(s => document.getElementById(s.id))
      .filter(Boolean);

    if (targets.length === 0) return;

    observerRef.current = new IntersectionObserver(
      entries => {
        // Find the topmost visible entry
        const visible = entries
          .filter(e => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible.length > 0) setActiveId(visible[0].target.id);
      },
      { rootMargin: '-15% 0px -70% 0px', threshold: 0 }
    );

    targets.forEach(t => observerRef.current.observe(t));
    return () => observerRef.current?.disconnect();
  }, [sections]);

  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const offset = 80; // navbar height
    const top = el.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
    setMobileOpen(false);
  };

  if (sections.length === 0) return null;

  const activeIndex = sections.findIndex(s => s.id === activeId);
  const progressPct = sections.length > 1
    ? (activeIndex / (sections.length - 1)) * 100
    : 0;

  return (
    <>
      {/* ── Desktop: fixed right panel ────────────────────────────── */}
      <nav className="hidden xl:flex fixed right-6 top-1/2 -translate-y-1/2 z-40 flex-col items-end gap-0 select-none">
        {/* Progress track */}
        <div className="flex gap-3 items-start px-3 py-3 rounded-sm" style={{ background: 'hsl(var(--background) / 0.75)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)', border: '1px solid hsl(var(--border) / 0.4)' }}>
          {/* Vertical track line */}
          <div className="relative w-px self-stretch mt-1 mb-1" style={{ minHeight: `${sections.length * 32}px` }}>
            {/* Track background */}
            <div className="absolute inset-0 bg-foreground/10" />
            {/* Active fill */}
            <div
              className="absolute top-0 left-0 right-0 bg-foreground/50 transition-all duration-500"
              style={{ height: `${progressPct}%` }}
            />
            {/* Active dot */}
            {activeIndex >= 0 && (
              <div
                className="absolute left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-foreground transition-all duration-500"
                style={{ top: `calc(${progressPct}% - 3px)` }}
              />
            )}
          </div>

          {/* Labels */}
          <div className="flex flex-col">
            {sections.map((s) => {
              const isActive = s.id === activeId;
              const label = lang === 'zh' ? s.label_zh : s.label_en;
              return (
                <button
                  key={s.id}
                  onClick={() => scrollTo(s.id)}
                  className={`text-left py-1 pl-0 pr-0 transition-all duration-300 mono-label text-[8px] leading-[1] h-8 flex items-center whitespace-nowrap ${
                    isActive
                      ? 'text-foreground font-medium'
                      : 'text-foreground/25 hover:text-foreground/55'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* ── Mobile: floating "Sections" button + dropdown ─────────── */}
      <div className="xl:hidden fixed bottom-6 right-4 z-40">
        {mobileOpen && (
          <div className="absolute bottom-12 right-0 w-44 bg-background border border-foreground/15 shadow-xl py-2 mb-1">
            {sections.map(s => {
              const isActive = s.id === activeId;
              const label = lang === 'zh' ? s.label_zh : s.label_en;
              return (
                <button
                  key={s.id}
                  onClick={() => scrollTo(s.id)}
                  className={`w-full text-left px-4 py-2.5 text-[11px] transition-colors ${
                    isActive
                      ? 'text-foreground bg-foreground/5 font-medium'
                      : 'text-foreground/45 hover:text-foreground hover:bg-foreground/[0.03]'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        )}
        <button
          onClick={() => setMobileOpen(v => !v)}
          className="flex items-center gap-1.5 bg-background border border-foreground/20 shadow-lg px-3 py-2 mono-label text-[9px] text-foreground/50 hover:text-foreground transition-colors"
        >
          {mobileOpen ? <X size={11} /> : <List size={11} />}
          {lang === 'en' ? 'Sections' : '章节'}
          {!mobileOpen && <ChevronDown size={9} className="text-foreground/30" />}
        </button>
      </div>
    </>
  );
}