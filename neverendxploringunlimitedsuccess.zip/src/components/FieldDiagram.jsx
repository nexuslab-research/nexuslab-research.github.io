import React, { useEffect, useRef } from 'react';
import { useApp } from '@/lib/AppContext';

/**
 * FieldDiagram — compact scientific field visualization for section backgrounds.
 * Renders a tight, elegant contour map / potential field — like a gravitational 
 * or atmospheric pressure field from a Nature journal figure.
 */
export default function FieldDiagram({ className = '', type = 'contour' }) {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const { theme } = useApp();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let w = canvas.width = canvas.offsetWidth;
    let h = canvas.height = canvas.offsetHeight;

    const isDark = theme === 'dark';
    const fg = isDark ? '220,228,240' : '20,30,60';
    let t = 0;

    const handleResize = () => {
      w = canvas.width = canvas.offsetWidth;
      h = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    const drawContour = () => {
      // Draw contour lines — like isobar / isotherm maps
      const numContours = 8;
      for (let c = 0; c < numContours; c++) {
        const progress = c / numContours;
        ctx.beginPath();
        const steps = 120;
        for (let i = 0; i <= steps; i++) {
          const px = (i / steps) * w;
          const base = h * 0.1 + progress * h * 0.8;
          const wave1 = Math.sin(px * 0.008 + t * 0.0004 + progress * 1.2) * h * 0.06;
          const wave2 = Math.sin(px * 0.015 - t * 0.0003 + progress * 2.1) * h * 0.03;
          const wave3 = Math.cos(px * 0.005 + t * 0.0002 + c) * h * 0.04;
          const py = base + wave1 + wave2 + wave3;
          if (i === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        const alpha = isDark
          ? (0.04 + (1 - Math.abs(progress - 0.5) * 2) * 0.1)
          : (0.03 + (1 - Math.abs(progress - 0.5) * 2) * 0.06);
        ctx.strokeStyle = `rgba(${fg},${alpha})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }
    };

    const drawOrbital = () => {
      // Single elegant orbital ellipse
      ctx.save();
      ctx.translate(w / 2, h / 2);
      ctx.rotate(t * 0.00015);
      ctx.beginPath();
      ctx.ellipse(0, 0, w * 0.42, h * 0.32, 0, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${fg},${isDark ? 0.08 : 0.04})`;
      ctx.lineWidth = 0.7;
      ctx.setLineDash([4, 16]);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
    };

    const draw = () => {
      animRef.current = requestAnimationFrame(draw);
      t++;
      ctx.clearRect(0, 0, w, h);
      if (type === 'contour') drawContour();
      if (type === 'orbital') drawOrbital();
      if (type === 'both') { drawContour(); drawOrbital(); }
    };

    draw();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme, type]);

  return (
    <canvas
      ref={canvasRef}
      className={`absolute inset-0 w-full h-full pointer-events-none ${className}`}
      style={{ opacity: theme === 'dark' ? 0.9 : 0.5 }}
    />
  );
}