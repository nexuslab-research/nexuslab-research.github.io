import React, { useState } from 'react';

/**
 * WatermarkedImage — displays an image with a "NEXUS LAB" watermark
 * overlaid in the bottom-right corner. Clicking opens the lightbox.
 */
export default function WatermarkedImage({ src, caption, onClick, className = '' }) {
  const [loaded, setLoaded] = useState(false);

  return (
    <div
      className={`group relative overflow-hidden cursor-pointer bg-foreground/[0.02] ${className}`}
      onClick={onClick}
    >
      {/* Loading placeholder */}
      {!loaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-5 h-5 border border-foreground/15 border-t-foreground/40 rounded-full animate-spin" />
        </div>
      )}

      {/* Image */}
      <img
        src={src}
        alt={caption}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-[1.03] ${
          loaded ? 'opacity-100' : 'opacity-0'
        }`}
      />

      {/* Watermark — logo in bottom-right corner */}
      {loaded && (
        <img
          src="https://media.base44.com/images/public/6a2be9d0fafad4f8e6783c4f/5cb39edd6_logo.png"
          alt="NEXUS LAB"
          className="absolute bottom-2 right-2 h-4 w-auto pointer-events-none select-none"
          style={{ opacity: 0.5, mixBlendMode: 'screen', filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.7))' }}
        />
      )}

      {/* Hover overlay */}
      <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/[0.04] transition-colors duration-300 pointer-events-none" />
    </div>
  );
}