import React, { useEffect, useRef } from 'react';
import { useApp } from '@/lib/AppContext';

export default function ParticleField() {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const { theme } = useApp();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;

    const isDark = theme === 'dark';

    const nodes = Array.from({ length: 80 }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      r: Math.random() * 1.5 + 0.5,
      pulse: Math.random() * Math.PI * 2,
    }));

    const handleMouseMove = (e) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };
    window.addEventListener('mousemove', handleMouseMove);

    const handleResize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    let frame = 0;
    const draw = () => {
      animRef.current = requestAnimationFrame(draw);
      frame++;
      ctx.clearRect(0, 0, w, h);

      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      nodes.forEach(n => {
        n.pulse += 0.02;
        n.x += n.vx;
        n.y += n.vy;

        const dx = mx - n.x;
        const dy = my - n.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          n.x -= dx * 0.003;
          n.y -= dy * 0.003;
        }

        if (n.x < 0) n.x = w;
        if (n.x > w) n.x = 0;
        if (n.y < 0) n.y = h;
        if (n.y > h) n.y = 0;
      });

      // Draw connections
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 140) {
            const alpha = (1 - dist / 140) * (isDark ? 0.25 : 0.12);
            ctx.beginPath();
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = isDark
              ? `rgba(59,130,246,${alpha})`
              : `rgba(37,99,235,${alpha})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      // Draw nodes
      nodes.forEach(n => {
        const pulseFactor = 0.8 + Math.sin(n.pulse) * 0.2;
        const r = n.r * pulseFactor;
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.fillStyle = isDark
          ? `rgba(59,130,246,${0.5 + Math.sin(n.pulse) * 0.3})`
          : `rgba(37,99,235,${0.4 + Math.sin(n.pulse) * 0.2})`;
        ctx.fill();
      });

      // Floating data streams
      if (frame % 3 === 0) {
        const streamCount = 3;
        for (let s = 0; s < streamCount; s++) {
          const sx = (w * 0.2 * s + frame * 0.5) % w;
          const alpha = isDark ? 0.04 : 0.02;
          ctx.beginPath();
          ctx.moveTo(sx, 0);
          ctx.lineTo(sx + 80, h);
          const grad = ctx.createLinearGradient(sx, 0, sx + 80, h);
          grad.addColorStop(0, `rgba(168,85,247,0)`);
          grad.addColorStop(0.5, `rgba(168,85,247,${alpha})`);
          grad.addColorStop(1, `rgba(59,130,246,0)`);
          ctx.strokeStyle = grad;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    };

    draw();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: 0.9 }}
    />
  );
}