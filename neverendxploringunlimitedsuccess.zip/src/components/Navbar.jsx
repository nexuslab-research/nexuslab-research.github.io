import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '@/lib/AppContext';
import { Menu, X } from 'lucide-react';

const NAV_LINKS = [
  { path: '/about',                 en: 'About',          zh: '关于我们' },
  { path: '/research/publications', en: 'Publications',   zh: '论文发表' },
  { path: '/research/patents',     en: 'Patents',         zh: '专利' },
  { path: '/research/other-projects', en: 'Other Projects', zh: '评测与产品' },
  { path: '/people',  en: 'People',  zh: '团队成员' },
];

export default function Navbar() {
  const { theme, lang, toggleTheme, toggleLang } = useApp();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => { setMobileOpen(false); }, [location]);

  const isActive = (path) => path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  const navLinkClass = (active) =>
    `text-[14px] tracking-wide transition-colors duration-200 relative ${active ? 'text-foreground font-medium' : 'text-foreground/60 hover:text-foreground'}`;

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'border-b border-border bg-background/80 backdrop-blur' : 'bg-transparent'}`}>
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10">
          <div className="flex items-center justify-between h-14 lg:h-16">
            <Link to="/" className="flex items-center group">
              <img src={theme === 'dark' ? "https://media.base44.com/images/public/6a2be9d0fafad4f8e6783c4f/5cb39edd6_logo.png" : "https://media.base44.com/images/public/6a2be9d0fafad4f8e6783c4f/51297daf9_logo.png"} alt="Nexus Lab" className="h-7 lg:h-8 w-auto shrink-0 group-hover:opacity-90 transition-opacity" />
            </Link>

            <div className="hidden lg:flex items-center gap-7">
              <Link to="/" className={navLinkClass(isActive('/'))}>
                {lang === 'en' ? 'Home' : '首页'}
                {isActive('/') && <span className="absolute -bottom-0.5 left-0 right-0 h-px bg-foreground/60" />}
              </Link>

              {NAV_LINKS.map(link => (
                <Link key={link.path} to={link.path} className={navLinkClass(isActive(link.path))}>
                  {lang === 'en' ? link.en : link.zh}
                  {isActive(link.path) && <span className="absolute -bottom-0.5 left-0 right-0 h-px bg-foreground/60" />}
                </Link>
              ))}
            </div>

            <div className="hidden lg:flex items-center gap-3">
              <button onClick={toggleLang}
                className="text-[12px] px-3 py-1.5 border border-border hover:border-foreground/40 text-foreground/60 hover:text-foreground transition-all duration-200">
                {lang === 'en' ? '中文' : 'EN'}
              </button>
              <button onClick={toggleTheme}
                className="text-[12px] px-3 py-1.5 border border-border hover:border-foreground/40 text-foreground/60 hover:text-foreground transition-all duration-200">
                {theme === 'dark' ? (lang === 'en' ? 'Light' : '日间') : (lang === 'en' ? 'Dark' : '夜间')}
              </button>
            </div>

            <div className="lg:hidden flex items-center gap-2">
              <button className="p-2 text-foreground/60 min-w-[44px] min-h-[44px] flex items-center justify-center" onClick={() => setMobileOpen(!mobileOpen)}>
                {mobileOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {mobileOpen && (
        <div className="fixed inset-0 z-40 flex flex-col pt-16 px-8 pb-8 overflow-y-auto bg-background">
          <div className="flex flex-col">
            <Link to="/" className={`text-2xl font-light py-4 border-b border-border transition-colors ${isActive('/') ? 'text-foreground' : 'text-foreground/65'}`}>{lang === 'en' ? 'Home' : '首页'}</Link>
            {NAV_LINKS.map(link => (
              <Link key={link.path} to={link.path} className={`text-2xl font-light py-4 border-b border-border transition-colors ${isActive(link.path) ? 'text-foreground' : 'text-foreground/40'}`}>{lang === 'en' ? link.en : link.zh}</Link>
            ))}
          </div>
          <div className="flex items-center gap-3 mt-8">
            <button onClick={toggleLang} className="text-[12px] px-3 py-2 border border-border text-foreground/60 hover:text-foreground transition-all">{lang === 'en' ? '中文' : 'EN'}</button>
            <button onClick={toggleTheme} className="text-[12px] px-3 py-2 border border-border text-foreground/60 hover:text-foreground transition-all">{theme === 'dark' ? (lang === 'en' ? 'Light' : '日间') : (lang === 'en' ? 'Dark' : '夜间')}</button>
          </div>
        </div>
      )}
    </>
  );
}