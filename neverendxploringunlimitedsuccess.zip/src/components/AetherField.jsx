import React, { useEffect, useRef } from 'react';
import { useApp } from '@/lib/AppContext';

/**
 * AetherField — Scientific visualization background.
 * Inspired by: NASA earth-systems simulations, gravitational field lines,
 * orbital mechanics diagrams, and Nature/Science journal figure aesthetics.
 *
 * Renders: concentric orbital rings, flowing field-line contours, 
 * slow-rotating ellipses, and sparse precise data-points — 
 * NO random glowing particles, NO circuit boards, NO AI clichés.
 */
export default function AetherField() {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const { theme } = useApp();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let w = canvas.width = canvas.offsetWidth;
    let h = canvas.height = canvas.offsetHeight;

    const isDark = theme === 'dark';

    // Scientific accent palette — spectral instrument colors
    const fg = isDark ? '180,200,230' : '40,60,100';
    const accent = isDark ? '140,180,255' : '80,120,180';
    // Multi-spectral colors for field lines
    const spectra = isDark
      ? ['140,180,255', '180,140,255', '100,220,200', '255,200,120', '160,220,255']
      : ['80,120,200', '120,80,180', '60,160,140', '180,130,60', '80,160,200'];

    // Orbital rings — elliptical, tilted, slowly rotating
    const orbitals = [
      { cx: w * 0.5, cy: h * 0.5, rx: Math.min(w, h) * 0.38, ry: Math.min(w, h) * 0.15, tilt: -0.3, speed: 0.00018, alpha: isDark ? 0.12 : 0.07, dash: [6, 14] },
      { cx: w * 0.5, cy: h * 0.5, rx: Math.min(w, h) * 0.55, ry: Math.min(w, h) * 0.22, tilt: 0.25, speed: -0.00012, alpha: isDark ? 0.08 : 0.05, dash: [2, 18] },
      { cx: w * 0.5, cy: h * 0.5, rx: Math.min(w, h) * 0.72, ry: Math.min(w, h) * 0.30, tilt: 0.6, speed: 0.00008, alpha: isDark ? 0.06 : 0.035, dash: [1, 24] },
    ];

    // Field-line contours — slow horizontal drift, sinusoidal amplitude
    const fieldLines = Array.from({ length: 14 }, (_, i) => ({
      baseY: h * 0.05 + (h * 0.9 / 13) * i,
      phase: (i / 13) * Math.PI * 2,
      amp: h * 0.018 + Math.random() * h * 0.022,
      freq: 0.004 + Math.random() * 0.003,
      speed: 0.00025 + Math.random() * 0.0003,
      offset: Math.random() * Math.PI * 2,
      alpha: isDark
        ? (0.05 + (1 - Math.abs(i - 6.5) / 6.5) * 0.09)
        : (0.04 + (1 - Math.abs(i - 6.5) / 6.5) * 0.05),
    }));

    // Sparse precise measurement points — like scientific instrument readings
    const dataPoints = Array.from({ length: 18 }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      size: Math.random() * 1.5 + 0.5,
      alpha: isDark ? (0.15 + Math.random() * 0.25) : (0.10 + Math.random() * 0.15),
      vx: (Math.random() - 0.5) * 0.08,
      vy: (Math.random() - 0.5) * 0.06,
    }));

    // Meridian grid lines — sparse, like a celestial sphere
    const meridians = Array.from({ length: 5 }, (_, i) => ({
      angle: (Math.PI / 4) * i,
      speed: 0.00005 * (i % 2 === 0 ? 1 : -1),
      alpha: isDark ? 0.05 : 0.03,
    }));

    let t = 0;

    const handleResize = () => {
      w = canvas.width = canvas.offsetWidth;
      h = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    const drawOrbital = (orb, time) => {
      const angle = time * orb.speed;
      ctx.save();
      ctx.translate(orb.cx, orb.cy);
      ctx.rotate(orb.tilt + angle);
      ctx.beginPath();
      ctx.ellipse(0, 0, orb.rx, orb.ry, 0, 0, Math.PI * 2);
      ctx.setLineDash(orb.dash);
      ctx.strokeStyle = `rgba(${fg},${orb.alpha})`;
      ctx.lineWidth = 0.8;
      ctx.stroke();
      ctx.setLineDash([]);

      // Small nodes on orbital path — measurement markers
      for (let i = 0; i < 4; i++) {
        const theta = (i / 4) * Math.PI * 2 + angle * 2;
        const px = Math.cos(theta) * orb.rx;
        const py = Math.sin(theta) * orb.ry;
        ctx.beginPath();
        ctx.arc(px, py, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${fg},${orb.alpha * 2.5})`;
        ctx.fill();
        // tick lines
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px * 1.04, py * 1.04);
        ctx.strokeStyle = `rgba(${fg},${orb.alpha * 2})`;
        ctx.lineWidth = 0.6;
        ctx.stroke();
      }
      ctx.restore();
    };

    const drawFieldLines = (time) => {
      fieldLines.forEach((fl, fi) => {
        ctx.beginPath();
        const steps = Math.ceil(w / 3);
        for (let x = 0; x <= steps; x++) {
          const px = (x / steps) * w;
          const drift = time * fl.speed * w;
          const py = fl.baseY
            + Math.sin((px + drift) * fl.freq + fl.phase) * fl.amp
            + Math.sin((px * 0.6 + drift * 0.7) * fl.freq * 1.6 + fl.offset) * fl.amp * 0.4;
          if (x === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        // Use spectral colors for field lines near center, neutral otherwise
        const distFromCenter = Math.abs(fi - 6.5) / 6.5;
        const color = distFromCenter < 0.4 ? spectra[fi % spectra.length] : fg;
        ctx.strokeStyle = `rgba(${color},${fl.alpha})`;
        ctx.lineWidth = 0.7;
        ctx.stroke();
      });
    };

    const drawMeridians = (time) => {
      meridians.forEach(m => {
        const angle = m.angle + time * m.speed;
        ctx.save();
        ctx.translate(w / 2, h / 2);
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.moveTo(-w, 0);
        ctx.lineTo(w, 0);
        ctx.strokeStyle = `rgba(${fg},${m.alpha})`;
        ctx.lineWidth = 0.5;
        ctx.setLineDash([3, 20]);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.restore();
      });
    };

    const drawDataPoints = () => {
      dataPoints.forEach(dp => {
        dp.x += dp.vx;
        dp.y += dp.vy;
        if (dp.x < 0) dp.x = w;
        if (dp.x > w) dp.x = 0;
        if (dp.y < 0) dp.y = h;
        if (dp.y > h) dp.y = 0;

        // cross-hair style — like instrument readings
        ctx.strokeStyle = `rgba(${fg},${dp.alpha})`;
        ctx.lineWidth = 0.7;
        ctx.beginPath();
        ctx.moveTo(dp.x - dp.size * 3, dp.y);
        ctx.lineTo(dp.x + dp.size * 3, dp.y);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(dp.x, dp.y - dp.size * 3);
        ctx.lineTo(dp.x, dp.y + dp.size * 3);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(dp.x, dp.y, dp.size, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(${fg},${dp.alpha * 0.6})`;
        ctx.stroke();
      });
    };

    // Central focus ring — like a scientific instrument aperture
    const drawFocusRing = (time) => {
      const cx = w / 2, cy = h / 2;
      const r1 = Math.min(w, h) * 0.06;
      const r2 = r1 * 1.6;
      
      // Inner ring
      ctx.beginPath();
      ctx.arc(cx, cy, r1, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(${fg},${isDark ? 0.18 : 0.10})`;
      ctx.lineWidth = 0.8;
      ctx.stroke();

      // Outer ring with gaps
      ctx.beginPath();
      ctx.arc(cx, cy, r2, 0.4 + time * 0.0002, Math.PI - 0.4 + time * 0.0002);
      ctx.strokeStyle = `rgba(${fg},${isDark ? 0.10 : 0.06})`;
      ctx.lineWidth = 0.6;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, r2, Math.PI + 0.4 + time * 0.0002, Math.PI * 2 - 0.4 + time * 0.0002);
      ctx.strokeStyle = `rgba(${fg},${isDark ? 0.10 : 0.06})`;
      ctx.lineWidth = 0.6;
      ctx.stroke();

      // Cardinal tick marks
      for (let i = 0; i < 8; i++) {
        const theta = (i / 8) * Math.PI * 2 + time * 0.0001;
        const inner = r2 * 0.92;
        const outer = r2 * 1.08;
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(theta) * inner, cy + Math.sin(theta) * inner);
        ctx.lineTo(cx + Math.cos(theta) * outer, cy + Math.sin(theta) * outer);
        ctx.strokeStyle = `rgba(${fg},${isDark ? 0.15 : 0.08})`;
        ctx.lineWidth = i % 2 === 0 ? 1 : 0.5;
        ctx.stroke();
      }
    };

    const draw = () => {
      animRef.current = requestAnimationFrame(draw);
      t++;
      ctx.clearRect(0, 0, w, h);

      drawMeridians(t);
      drawFieldLines(t);
      orbitals.forEach(orb => drawOrbital(orb, t));
      drawFocusRing(t);
      drawDataPoints();
    };

    draw();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: theme === 'dark' ? 0.85 : 0.6 }}
    />
  );
}