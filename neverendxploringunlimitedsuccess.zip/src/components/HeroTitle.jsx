import React from 'react';
import { useApp } from '@/lib/AppContext';

export default function HeroTitle() {
  const { lang } = useApp();

  return (
    <div className="text-center max-w-3xl">
      <h1 className="text-[clamp(2.55rem,7.65vw,6.8rem)] font-bold leading-[1.02] tracking-[-0.02em] mb-6 text-foreground">
        Nexus Lab
      </h1>
      <p className="text-[15px] text-muted-foreground mb-7 tracking-wide">
        Never End Xploring Unbounded Spirit
      </p>
      <p className="text-[17px] text-foreground/60 max-w-xl mx-auto leading-relaxed">
        {lang === 'en'
          ? 'Our team is dedicated to advancing scientific discovery and the understanding of the real physical world.'
          : '团队致力于推动科学发现与理解真实物理世界。'}
      </p>
    </div>
  );
}