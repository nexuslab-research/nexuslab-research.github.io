import React, { useEffect, useRef } from 'react';
import { useApp } from '@/lib/AppContext';

/**
 * IntelligenceCore — Dual-mode visualization
 * Dark  → Abstract data topology (orbital rings, field lines, nucleus)
 * Light → Realistic rotating wireframe Earth with atmosphere
 * Transition: morphProgress 0→1 interpolates smoothly over ~1.2s
 */
export default function IntelligenceCore({ size = 520 }) {
  const canvasRef  = useRef(null);
  const animRef    = useRef(null);
  const morphRef   = useRef({ progress: 0, target: 0, animating: false, startProgress: 0, startTime: 0 });
  const tRef       = useRef(0);
  const { theme }  = useApp();

  // Update morph target when theme changes
  useEffect(() => {
    const target = theme === 'dark' ? 0 : 1;
    const m = morphRef.current;
    if (m.target !== target) {
      m.target        = target;
      m.startProgress = m.progress;
      m.startTime     = performance.now();
      m.animating     = true;
    }
  }, [theme]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    canvas.width  = size * dpr;
    canvas.height = size * dpr;
    canvas.style.width  = size + 'px';
    canvas.style.height = size + 'px';
    ctx.scale(dpr, dpr);

    const cx = size / 2;
    const cy = size / 2;
    const DURATION = 700; // ms — faster, more impactful

    // Set initial morph based on theme at mount
    morphRef.current.progress = theme === 'dark' ? 0 : 1;
    morphRef.current.target   = theme === 'dark' ? 0 : 1;

    // Easing — Expo Out for impact
    function easeOutExpo(x) {
      return x === 1 ? 1 : 1 - Math.pow(2, -10 * x);
    }

    function lerp(a, b, t) { return a + (b - a) * t; }

    // ── Dark mode colors
    const DC = ['190,210,255', '140,180,255', '180,140,255', '100,220,200', '255,200,120', '160,220,255'];

    function drawDataMode(ctx, t, alpha) {
      if (alpha <= 0) return;
      ctx.globalAlpha = alpha;

      // Measurement rings
      [
        { r: size * 0.46, dash: [2, 12], a: 0.12, w: 0.6 },
        { r: size * 0.38, dash: [4, 8],  a: 0.18, w: 0.7 },
        { r: size * 0.30, dash: [1, 6],  a: 0.22, w: 0.5 },
      ].forEach(ring => {
        ctx.beginPath();
        ctx.arc(cx, cy, ring.r, 0, Math.PI * 2);
        ctx.setLineDash(ring.dash);
        ctx.strokeStyle = `rgba(180,200,230,${ring.a})`;
        ctx.lineWidth = ring.w;
        ctx.stroke();
        ctx.setLineDash([]);
      });

      // Orbital scan arcs
      [
        { r: size * 0.42, speed: 0.18,  a: 0.25, len: Math.PI * 0.6, ci: 0 },
        { r: size * 0.35, speed: -0.28, a: 0.20, len: Math.PI * 0.4, ci: 1 },
        { r: size * 0.27, speed: 0.35,  a: 0.15, len: Math.PI * 0.3, ci: 2 },
      ].forEach((orb, oi) => {
        const angle = t * orb.speed + oi * 1.2;
        ctx.beginPath();
        ctx.arc(cx, cy, orb.r, angle, angle + orb.len);
        ctx.strokeStyle = `rgba(${DC[orb.ci]},${orb.a})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
        const nx = cx + Math.cos(angle + orb.len) * orb.r;
        const ny = cy + Math.sin(angle + orb.len) * orb.r;
        ctx.beginPath();
        ctx.arc(nx, ny, 2, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${DC[orb.ci]},${orb.a * 2})`;
        ctx.fill();
      });

      // Biological membranes
      for (let m = 0; m < 6; m++) {
        const prog  = m / 6;
        const baseR = size * (0.08 + prog * 0.16);
        const ci    = m % DC.length;
        const pulse = Math.sin(t * 0.7 + m * 0.8) * 0.3 + 0.7;
        const a     = (0.04 + (1 - prog) * 0.08) * pulse;
        ctx.beginPath();
        for (let ang = 0; ang <= Math.PI * 2; ang += 0.05) {
          const wob = 1
            + Math.sin(ang * 3 + t * 0.6 + m) * 0.04
            + Math.sin(ang * 5 - t * 0.4 + m * 1.3) * 0.025
            + Math.sin(ang * 7 + t * 0.3) * 0.015;
          const r  = baseR * wob;
          const px = cx + Math.cos(ang) * r;
          const py = cy + Math.sin(ang) * r;
          if (ang <= 0.05) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, baseR * 1.2);
        g.addColorStop(0, `rgba(${DC[ci]},${a * 2})`);
        g.addColorStop(0.5, `rgba(${DC[ci]},${a})`);
        g.addColorStop(1, `rgba(${DC[ci]},0)`);
        ctx.fillStyle = g;
        ctx.fill();
        ctx.strokeStyle = `rgba(${DC[ci]},${a * 1.5})`;
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Field lines
      for (let f = 0; f < 12; f++) {
        const ang   = (f / 12) * Math.PI * 2;
        const ci    = f % DC.length;
        const phase = t * 0.4 + f * 0.3;
        ctx.beginPath();
        for (let s = 0; s <= 40; s++) {
          const p   = s / 40;
          const r   = size * 0.06 + p * size * 0.36;
          const def = Math.sin(phase + p * Math.PI * 2) * 0.15 * (1 - p);
          const a2  = ang + def;
          const px  = cx + Math.cos(a2) * r;
          const py  = cy + Math.sin(a2) * r;
          if (s === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.strokeStyle = `rgba(${DC[ci]},${0.04 + Math.sin(t * 0.5 + f) * 0.02})`;
        ctx.lineWidth = 0.6;
        ctx.stroke();
      }

      // Core nucleus
      const cR  = size * 0.05;
      const cPulse = Math.sin(t * 1.2) * 0.15 + 0.85;
      const glow   = ctx.createRadialGradient(cx, cy, 0, cx, cy, cR * 4);
      glow.addColorStop(0, `rgba(${DC[0]},0.25)`);
      glow.addColorStop(0.4, `rgba(${DC[1]},0.08)`);
      glow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.beginPath(); ctx.arc(cx, cy, cR * 4, 0, Math.PI * 2);
      ctx.fillStyle = glow; ctx.fill();
      const body = ctx.createRadialGradient(cx - cR * 0.3, cy - cR * 0.3, 0, cx, cy, cR * cPulse);
      body.addColorStop(0, `rgba(${DC[0]},0.9)`);
      body.addColorStop(0.5, `rgba(${DC[1]},0.6)`);
      body.addColorStop(1, `rgba(${DC[2]},0.15)`);
      ctx.beginPath(); ctx.arc(cx, cy, cR * cPulse, 0, Math.PI * 2);
      ctx.fillStyle = body; ctx.fill();

      // Tick marks
      for (let i = 0; i < 36; i++) {
        const ang   = (i / 36) * Math.PI * 2 + t * 0.02;
        const r     = size * 0.46;
        const major = i % 9 === 0;
        const tl    = major ? 10 : 4;
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(ang) * r, cy + Math.sin(ang) * r);
        ctx.lineTo(cx + Math.cos(ang) * (r + tl), cy + Math.sin(ang) * (r + tl));
        ctx.strokeStyle = `rgba(180,200,230,${major ? 0.35 : 0.12})`;
        ctx.lineWidth = major ? 1 : 0.5;
        ctx.stroke();
      }

      // Scan beam
      const sa = t * 0.4;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(sa) * size * 0.46, cy + Math.sin(sa) * size * 0.46);
      ctx.strokeStyle = `rgba(${DC[0]},0.18)`;
      ctx.lineWidth = 1; ctx.stroke();

      // Crosshair annotations
      [0.8, 2.1, 3.7, 5.0].forEach((a, i) => {
        const r  = size * 0.38 + Math.sin(t * 0.3 + i) * size * 0.02;
        const px = cx + Math.cos(a + t * 0.05) * r;
        const py = cy + Math.sin(a + t * 0.05) * r;
        const c  = DC[i % DC.length];
        ctx.strokeStyle = `rgba(${c},0.6)`; ctx.lineWidth = 0.8;
        ctx.beginPath(); ctx.moveTo(px - 5, py); ctx.lineTo(px + 5, py); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(px, py - 5); ctx.lineTo(px, py + 5); ctx.stroke();
        ctx.beginPath(); ctx.arc(px, py, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${c},0.8)`; ctx.fill();
        ctx.beginPath(); ctx.moveTo(px + 6, py); ctx.lineTo(px + 18, py);
        ctx.strokeStyle = `rgba(${c},0.3)`; ctx.lineWidth = 0.5; ctx.stroke();
      });

      ctx.globalAlpha = 1;
    }

    function drawEarthMode(ctx, t, alpha) {
      if (alpha <= 0) return;
      ctx.globalAlpha = alpha;

      const R    = size * 0.38;
      const spin = t * 0.18;
      const TILT = 0.41; // ~23.4° in radians

      // Atmosphere halo
      const atm = ctx.createRadialGradient(cx, cy, R * 0.9, cx, cy, R * 1.25);
      atm.addColorStop(0, 'rgba(80,140,220,0.13)');
      atm.addColorStop(0.6, 'rgba(60,120,200,0.05)');
      atm.addColorStop(1, 'rgba(40,80,160,0)');
      ctx.beginPath(); ctx.arc(cx, cy, R * 1.25, 0, Math.PI * 2);
      ctx.fillStyle = atm; ctx.fill();

      // Globe base fill
      const sphere = ctx.createRadialGradient(
        cx - R * 0.3, cy - R * 0.3, R * 0.02,
        cx, cy, R
      );
      sphere.addColorStop(0,   'rgba(200,222,255,0.12)');
      sphere.addColorStop(0.55,'rgba(130,170,230,0.06)');
      sphere.addColorStop(1,   'rgba(20,40,85,0.14)');
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = sphere; ctx.fill();

      // Clip all wireframe lines to globe circle
      ctx.save();
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.clip();

      // Day/night terminator wash
      const term = ctx.createLinearGradient(cx - R, cy, cx + R, cy);
      term.addColorStop(0,    'rgba(10,20,55,0.18)');
      term.addColorStop(0.45, 'rgba(10,20,55,0.04)');
      term.addColorStop(0.55, 'rgba(255,230,160,0.03)');
      term.addColorStop(1,    'rgba(255,230,160,0.00)');
      ctx.fillStyle = term;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

      // Latitude parallels (9 lines)
      for (let p = 1; p <= 8; p++) {
        const lat    = (p / 9) * Math.PI - Math.PI / 2;
        const cosLat = Math.cos(lat);
        const sinLat = Math.sin(lat);
        const ry     = cy + R * sinLat * Math.cos(TILT);
        const rx     = R * cosLat;
        const ellt   = Math.abs(rx * Math.sin(TILT)) + 1;
        const isEq   = p === 4;
        const fade   = 1 - Math.abs(sinLat) * 0.45;
        ctx.beginPath();
        ctx.ellipse(cx, ry, Math.max(rx, 1), Math.max(ellt, 1.2), 0, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(55,105,185,${(isEq ? 0.32 : 0.14) * fade})`;
        ctx.lineWidth   = isEq ? 1.0 : 0.55;
        ctx.setLineDash(isEq ? [] : [3, 5]);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Longitude meridians (12 lines, rotating)
      for (let m = 0; m < 12; m++) {
        const lon     = (m / 12) * Math.PI * 2 + spin;
        const cosLon  = Math.cos(lon);
        const isPrime = m === 0;
        const vis     = (cosLon + 1) / 2; // front-facing visibility
        const rx      = Math.abs(R * cosLon);
        const lineA   = (isPrime ? 0.32 : 0.13) * (0.15 + vis * 0.85);
        const tiltRot = lon * Math.sin(TILT) * 0.28;
        ctx.beginPath();
        ctx.ellipse(cx, cy, Math.max(rx, 0.5), R, tiltRot, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(45,95,175,${lineA})`;
        ctx.lineWidth   = isPrime ? 0.9 : 0.5;
        ctx.setLineDash(isPrime ? [] : [4, 6]);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Specular highlight
      const spec = ctx.createRadialGradient(
        cx - R * 0.38, cy - R * 0.38, 0,
        cx - R * 0.22, cy - R * 0.22, R * 0.52
      );
      spec.addColorStop(0, 'rgba(225,240,255,0.20)');
      spec.addColorStop(1, 'rgba(225,240,255,0)');
      ctx.fillStyle = spec;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

      // Observation crosshairs on globe surface
      [0.5, 1.9, 3.3, 4.8].forEach((a, i) => {
        const r  = R * 0.72 + Math.sin(t * 0.25 + i) * R * 0.06;
        const px = cx + Math.cos(a + t * 0.04) * r;
        const py = cy + Math.sin(a + t * 0.04) * r;
        ctx.strokeStyle = 'rgba(70,130,215,0.50)'; ctx.lineWidth = 0.8;
        ctx.beginPath(); ctx.moveTo(px - 4, py); ctx.lineTo(px + 4, py); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(px, py - 4); ctx.lineTo(px, py + 4); ctx.stroke();
        ctx.beginPath(); ctx.arc(px, py, 1.2, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(110,175,255,0.75)'; ctx.fill();
        ctx.beginPath(); ctx.moveTo(px + 5, py); ctx.lineTo(px + 14, py);
        ctx.strokeStyle = 'rgba(70,130,215,0.25)'; ctx.lineWidth = 0.5; ctx.stroke();
      });

      ctx.restore(); // end clip

      // Globe border
      ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(75,125,210,0.32)';
      ctx.lineWidth = 1.2; ctx.stroke();

      // Outer instrument ring + ticks
      const OR = R + 18;
      ctx.beginPath(); ctx.arc(cx, cy, OR, 0, Math.PI * 2);
      ctx.setLineDash([2, 10]);
      ctx.strokeStyle = 'rgba(60,100,180,0.16)';
      ctx.lineWidth = 0.7; ctx.stroke(); ctx.setLineDash([]);

      for (let i = 0; i < 36; i++) {
        const ang   = (i / 36) * Math.PI * 2;
        const major = i % 9 === 0;
        const tl    = major ? 10 : 4;
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(ang) * OR, cy + Math.sin(ang) * OR);
        ctx.lineTo(cx + Math.cos(ang) * (OR + tl), cy + Math.sin(ang) * (OR + tl));
        ctx.strokeStyle = `rgba(60,100,180,${major ? 0.35 : 0.12})`;
        ctx.lineWidth = major ? 1 : 0.5; ctx.stroke();
      }

      // Satellite orbital arc
      const sa  = -t * 0.22;
      const oR  = R + 7;
      ctx.beginPath();
      ctx.arc(cx, cy, oR, sa, sa + Math.PI * 0.7);
      ctx.strokeStyle = 'rgba(80,160,220,0.24)';
      ctx.lineWidth = 1; ctx.stroke();
      const sx = cx + Math.cos(sa + Math.PI * 0.7) * oR;
      const sy = cy + Math.sin(sa + Math.PI * 0.7) * oR;
      ctx.beginPath(); ctx.arc(sx, sy, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(120,200,255,0.75)'; ctx.fill();

      ctx.globalAlpha = 1;
    }

    function frame(now) {
      animRef.current = requestAnimationFrame(frame);
      tRef.current += 0.010;
      const t = tRef.current;
      const m = morphRef.current;

      // Update morph progress
      if (m.animating) {
        const elapsed = now - m.startTime;
        const raw     = Math.min(elapsed / DURATION, 1);
        m.progress    = lerp(m.startProgress, m.target, easeOutExpo(raw));
        if (raw >= 1) { m.progress = m.target; m.animating = false; }
      }

      ctx.clearRect(0, 0, size, size);

      const mp = m.progress; // 0=dark/data, 1=light/earth
      drawDataMode(ctx, t, 1 - mp);
      drawEarthMode(ctx, t, mp);
    }

    animRef.current = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(animRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [size]);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none"
      style={{ width: size, height: size }}
    />
  );
}