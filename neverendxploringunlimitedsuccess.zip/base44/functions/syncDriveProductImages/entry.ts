import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const FOLDER_ID = '1W0jo4WJO5e2TUfJYZdW2MJ5UUyJb-C70';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Allow overriding folder ID via request body
    let folderId = FOLDER_ID;
    try {
      const body = await req.clone().json();
      if (body.folder_id) folderId = body.folder_id;
    } catch (_) {}

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('googledrive');
    const authHeader = { Authorization: `Bearer ${accessToken}` };

    // List all images in the folder (paginated)
    let allFiles = [];
    let pageToken = null;
    do {
      const query = `'${folderId}' in parents and mimeType contains 'image/' and trashed=false`;
      let url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(query)}&fields=files(id,name,mimeType,modifiedTime),nextPageToken&pageSize=200`;
      if (pageToken) url += `&pageToken=${pageToken}`;
      const res = await fetch(url, { headers: authHeader });
      if (!res.ok) {
        const err = await res.text();
        return Response.json({ error: `Drive list error: ${err}` }, { status: 502 });
      }
      const data = await res.json();
      allFiles.push(...(data.files || []));
      pageToken = data.nextPageToken;
    } while (pageToken);

    // Get existing records
    const existing = await base44.asServiceRole.entities.ProductImage.filter({}, '-created_date', 500);
    const existingMap = {};
    existing.forEach(p => { existingMap[p.drive_file_id] = p; });

    let newCount = 0, updatedCount = 0, skippedCount = 0;
    const seenIds = new Set();

    for (const file of allFiles) {
      seenIds.add(file.id);
      const existingRec = existingMap[file.id];

      // Skip if not modified since last sync
      if (existingRec && existingRec.drive_modified === file.modifiedTime && existingRec.file_url) {
        skippedCount++;
        continue;
      }

      // Download image from Drive
      const downloadUrl = `https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`;
      const imgRes = await fetch(downloadUrl, { headers: authHeader });
      if (!imgRes.ok) continue;
      const blob = await imgRes.blob();

      // Upload to Base44 storage
      const fileObj = new File([blob], file.name, { type: file.mimeType });
      const uploadResult = await base44.asServiceRole.integrations.Core.UploadFile({ file: fileObj });
      const file_url = uploadResult.file_url;

      // Remove extension from filename for caption
      const caption = file.name.replace(/\.[^/.]+$/, '');

      if (existingRec) {
        await base44.asServiceRole.entities.ProductImage.update(existingRec.id, {
          name: caption,
          file_url,
          mime_type: file.mimeType,
          drive_modified: file.modifiedTime,
        });
        updatedCount++;
      } else {
        await base44.asServiceRole.entities.ProductImage.create({
          drive_file_id: file.id,
          name: caption,
          file_url,
          mime_type: file.mimeType,
          drive_modified: file.modifiedTime,
        });
        newCount++;
      }
    }

    // Delete records for files removed from Drive
    let deletedCount = 0;
    for (const rec of existing) {
      if (!seenIds.has(rec.drive_file_id)) {
        await base44.asServiceRole.entities.ProductImage.delete(rec.id);
        deletedCount++;
      }
    }

    return Response.json({
      status: 'ok',
      total_files: allFiles.length,
      new: newCount,
      updated: updatedCount,
      skipped: skippedCount,
      deleted: deletedCount,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});