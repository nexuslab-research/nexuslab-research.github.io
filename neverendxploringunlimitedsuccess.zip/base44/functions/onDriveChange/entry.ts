import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Google Drive webhooks signal that something changed — body is mostly empty.
    // We do a full re-sync which handles add/update/delete detection.
    const { accessToken } = await base44.asServiceRole.connectors.getConnection('googledrive');
    const authHeader = { Authorization: `Bearer ${accessToken}` };

    // List all PDF files (paginate)
    let allFiles = [];
    let pageToken = null;
    do {
      const params = new URLSearchParams({
        q: "mimeType='application/pdf' and trashed=false",
        fields: 'nextPageToken,files(id,name,createdTime,modifiedTime,webViewLink)',
        pageSize: '200',
        orderBy: 'createdTime desc'
      });
      if (pageToken) params.set('pageToken', pageToken);
      const res = await fetch(`https://www.googleapis.com/drive/v3/files?${params}`, { headers: authHeader });
      if (!res.ok) {
        const err = await res.text();
        return Response.json({ error: `Drive API error: ${err}` }, { status: 502 });
      }
      const data = await res.json();
      allFiles.push(...(data.files || []));
      pageToken = data.nextPageToken;
    } while (pageToken);

    // Get existing publications keyed by drive_file_id
    const existing = await base44.asServiceRole.entities.Publication.filter({}, '-created_date', 500);
    const existingMap = {};
    existing.forEach(p => { if (p.drive_file_id) existingMap[p.drive_file_id] = p; });

    let newCount = 0;
    let updatedCount = 0;
    const driveFileIds = new Set();

    for (const file of allFiles) {
      driveFileIds.add(file.id);
      const rawName = file.name.replace(/\.pdf$/i, '');
      const yearMatch = rawName.match(/(20\d{2})/);
      const year = yearMatch ? yearMatch[1] : new Date(file.createdTime).getFullYear().toString();
      const title = rawName.replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
      const pdfUrl = file.webViewLink || '';

      const existingPub = existingMap[file.id];
      if (existingPub) {
        if (file.modifiedTime !== existingPub.drive_modified) {
          await base44.asServiceRole.entities.Publication.update(existingPub.id, {
            title, year, pdf_url: pdfUrl, drive_modified: file.modifiedTime
          });
          updatedCount++;
        }
      } else {
        await base44.asServiceRole.entities.Publication.create({
          title, authors: '', venue: '', year, domain: 'general',
          pdf_url: pdfUrl, drive_file_id: file.id, drive_modified: file.modifiedTime
        });
        newCount++;
      }
    }

    // Delete publications whose Drive file was removed
    let deletedCount = 0;
    for (const p of existing) {
      if (p.drive_file_id && !driveFileIds.has(p.drive_file_id)) {
        await base44.asServiceRole.entities.Publication.delete(p.id);
        deletedCount++;
      }
    }

    return Response.json({
      status: 'ok',
      total_drive_files: allFiles.length,
      new: newCount, updated: updatedCount, deleted: deletedCount
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});