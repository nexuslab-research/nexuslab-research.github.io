import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    let spreadsheetId = '1pKFrgZ8twevYrBCzGdRwz4eVsjmENma4mwKAzxOHogc';

    // Allow overriding spreadsheet ID via request body
    try {
      const body = await req.clone().json();
      if (body.spreadsheet_id) spreadsheetId = body.spreadsheet_id;
    } catch (_) {}

    const { accessToken } = await base44.asServiceRole.connectors.getConnection('googledrive');
    const authHeader = { Authorization: `Bearer ${accessToken}` };

    // Export the Google Sheet as CSV via Drive API
    const exportUrl = `https://www.googleapis.com/drive/v3/files/${spreadsheetId}/export?mimeType=text/csv`;
    const res = await fetch(exportUrl, { headers: authHeader });
    if (!res.ok) {
      const err = await res.text();
      return Response.json({ error: `Drive export error: ${err}` }, { status: 502 });
    }
    const csvText = await res.text();
    const rows = parseCSV(csvText);

    if (rows.length < 2) {
      return Response.json({ error: 'No data rows found in spreadsheet', csv_preview: csvText.substring(0, 500) }, { status: 400 });
    }

    const headers = rows[0].map(h => h.trim().toLowerCase());

    // Match columns by bilingual header names (EN + CN, separated by /)
    const colMap = {
      title: findColumn(headers, ['title', '论文标题', '标题', 'paper title']),
      authors: findColumn(headers, ['authors', '作者']),
      year: findColumn(headers, ['year', '发表日期', '年份']),
      venue: findColumn(headers, ['venue', '发表载体', '期刊', '会议']),
      website_page: findColumn(headers, ['website page', '论文主页', 'website', '主页']),
      volume: findColumn(headers, ['volume', '卷号']),
      issue: findColumn(headers, ['issue', '期号']),
      pages: findColumn(headers, ['pages', '页码']),
      pdf_url: findColumn(headers, ['pdf link', 'pdf链接', 'pdf', 'pdf_url', 'url', 'link']),
      abstract: findColumn(headers, ['abstract', '摘要']),
    };

    // Get existing publications to avoid duplicates (match by pdf_url or title)
    const existing = await base44.asServiceRole.entities.Publication.filter({}, '-created_date', 500);
    const existingByPdfUrl = {};
    const existingByTitle = {};
    existing.forEach(p => {
      if (p.pdf_url) existingByPdfUrl[p.pdf_url] = p;
      if (p.title) existingByTitle[p.title.toLowerCase().trim()] = p;
    });

    let newCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      if (!row || row.every(c => !c || !c.trim())) { skippedCount++; continue; }

      const title = colMap.title >= 0 ? (row[colMap.title] || '').trim() : '';
      const pdfUrl = colMap.pdf_url >= 0 ? (row[colMap.pdf_url] || '').trim() : '';

      if (!title && !pdfUrl) { skippedCount++; continue; }

      const authors = colMap.authors >= 0 ? (row[colMap.authors] || '').trim() : '';
      const year = colMap.year >= 0 ? (row[colMap.year] || '').trim() : '';
      const venue = colMap.venue >= 0 ? (row[colMap.venue] || '').trim() : '';
      const websitePage = colMap.website_page >= 0 ? (row[colMap.website_page] || '').trim() : '';
      const volume = colMap.volume >= 0 ? (row[colMap.volume] || '').trim() : '';
      const issue = colMap.issue >= 0 ? (row[colMap.issue] || '').trim() : '';
      const pages = colMap.pages >= 0 ? (row[colMap.pages] || '').trim() : '';
      const abstract = colMap.abstract >= 0 ? (row[colMap.abstract] || '').trim() : '';

      const fields = {
        authors,
        year,
        venue,
        website_page: websitePage,
        volume,
        issue,
        pages,
        pdf_url: pdfUrl,
        abstract,
      };

      const existingPub = (pdfUrl && existingByPdfUrl[pdfUrl]) || (title && existingByTitle[title.toLowerCase()]);

      if (existingPub) {
        await base44.asServiceRole.entities.Publication.update(existingPub.id, {
          ...(title ? { title } : {}),
          ...fields,
        });
        updatedCount++;
      } else {
        await base44.asServiceRole.entities.Publication.create({
          title: title || 'Untitled',
          ...fields,
        });
        newCount++;
      }
    }

    // Clean up legacy domain/research_domain fields from all records
    try {
      await base44.asServiceRole.entities.Publication.updateMany({}, { $unset: { domain: '', research_domain: '' } });
    } catch (_) {}

    return Response.json({
      status: 'ok',
      total_rows: rows.length - 1,
      new: newCount,
      updated: updatedCount,
      skipped: skippedCount,
      detected_columns: colMap,
      headers_found: headers,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function parseCSV(text) {
  const rows = [];
  let current = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else { inQuotes = false; }
      } else { field += c; }
    } else {
      if (c === '"') { inQuotes = true; }
      else if (c === ',') { current.push(field); field = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        current.push(field); field = '';
        if (current.some(c => c.trim())) rows.push(current);
        current = [];
      } else { field += c; }
    }
  }
  if (field || current.length > 0) {
    current.push(field);
    if (current.some(c => c.trim())) rows.push(current);
  }
  return rows;
}

function findColumn(headers, names) {
  // Exact match
  for (const name of names) {
    const idx = headers.indexOf(name);
    if (idx >= 0) return idx;
  }
  // Substring match
  for (const name of names) {
    const idx = headers.findIndex(h => h.includes(name));
    if (idx >= 0) return idx;
  }
  // Split on / and match each part (bilingual headers like "research domain/研究方向")
  for (const name of names) {
    const idx = headers.findIndex(h => h.split('/').some(part => part.trim() === name));
    if (idx >= 0) return idx;
  }
  return -1;
}